###############################################################################
import re
import xml.etree.cElementTree as ET

from metaclassManager import Parser
from metaclassManager import MetaClass
from metaclassManager import MetaClassParser
from metaclassManager import MetaClassManager
from tapiclass import TapiParam, TapiSwitch, TapiBind
from tapiclass import TapiClass
from tapiclass import TapiClassCondition
from tapiclass import TapiMap
from tapiclass import TapiInterface
from tapiclass import TapiRetval

nss = {'tapi': 'urn:www.spirentcom.com:XMLSchema.xsd'}
ET.register_namespace('tapi', 'urn:www.spirentcom.com:XMLSchema.xsd')


class TapiInfoParser(Parser):
    interfaceDict = {}

    def __init__(self, name=""):
        self.m_curClsList = {}

    @staticmethod
    def isInInterface(name):
        for el in TapiInfoParser.interfaceDict:
            element = TapiInfoParser.interfaceDict[el]
            result = re.search(name, element.from_object)
            if result is not None:
                return element
        return None
        
    def getTapiClsList(self):
        return self.m_curClsList

    @staticmethod
    def getPluginNameFrom(apiName):
        if apiName in TapiInfoParser.interfaceDict:
            interface = TapiInfoParser.interfaceDict[apiName]
            return interface.plugin
        return None
    
    @staticmethod
    def getInterfaceFrom(clsName):
        for intf, interface in TapiInfoParser.interfaceDict.items():
            ret = re.search(clsName, interface.from_object, flags=re.I)
            if ret is not None:
                return interface
        return None
    
    def dealDisableTrue(self, param, curMap=""):
        plugin = self.pluginName
        paramName = param.get("name")
        result = re.match(r"(.*)\.(.*)", paramName)
        tValue = param.findall("./tapi:value", nss)
        if result is not None:
            myproto = result.group(1).lower()
            myprop = result.group(2).lower()
            myCls = MetaClassManager.getMappedClass(plugin, myproto)
            if isinstance(myCls, MetaClass):
                myCls.removeProp(myprop)
            elif curMap != "":
                objs = curMap.getObjects()
                prefixs = curMap.getPrefixes()
                for element in objs:
                    myname = myproto.replace("$object$", element).lower()
                    myCls = MetaClassManager.getMappedClass(plugin, myname)
                    if isinstance(myCls, MetaClass):
                        myCls.removeProp(myprop)

    def read_xml(self, file):
        dom = Parser.read_xml(self, file)
        self.pluginName = dom.getroot().get('plugin')
        self.packageName = dom.getroot().get('package')

        GetMappedClsFunc = MetaClassManager.getMappedClass
        clsList = dom.getroot().findall("./tapi:class", nss)
        for cls in clsList:
            clsd = cls.get("disable")
            clsn = cls.get("name")
            if clsd == "TRUE":
                mycls = GetMappedClsFunc(self.pluginName, clsn)
                mycls.setCanCreate("false")
            else:
                alist = clsn.split(' ')
                for acls in alist:
                    curCls = TapiClass(acls)
                    self.m_curClsList[acls.lower()] = curCls
                    condList = cls.findall("./tapi:condition", nss)
                    for cond in condList:
                        cond = TapiClassCondition(cond.get("property"),
                                                  cond.get("operator"),
                                                  cond.get("value"),
                                                  cond.get("type"))
                        curCls.addClsCondition(cond)
        replace_map = {}
        itfList = dom.getroot().findall("./tapi:interface", nss)
        for itf in itfList:
            myfrom_to = itf.get("from_to_object")
            apiName = itf.get("APIName")
            b_all = itf.get("process_all_props", "TRUE")
            auto_prefix = itf.get("auto_prefix", "")
            cur = TapiInterface(apiName, myfrom_to, self.pluginName,
                                b_all, auto_prefix)
            TapiInfoParser.interfaceDict[apiName] = cur

            retList = itf.findall("./tapi:retval", nss)
            for ret in retList:
                keyList = ret.findall("./tapi:retkey", nss)
                curRetval = TapiRetval(ret.get("name"))
                for key in keyList:
                    obj = key.get("object").lower()
                    name = key.get("name")
                    curRetval.addRetKey(obj, name)
                    obj = GetMappedClsFunc(self.pluginName, obj)
                    children = obj.getBaseChildren()
                    if children != "":
                        for c in children.split(" "):
                            if c != "":
                                curRetval.addRetKey(c, name)
                cur.addRetVal(curRetval)

            paramList = itf.findall("./tapi:param", nss)
            for param in paramList:
                disable = param.get("disable")
                if disable is None or disable == "FALSE":
                    name = param.get("name")
                    alias = param.get("alias")
                    mybind = None
                    bind = param.get("bind")
                    if bind is not None:
                        mybind = TapiBind(name, alias, bind)
                    myproto = re.sub('\..*', "", name.lower())
                    myparam = TapiParam(name, alias)
                    myproto = GetMappedClsFunc(self.pluginName, myproto)
                    if isinstance(myproto, MetaClass):
                        myproto.addParam(myparam, mybind)
                    switchList = param.findall("./tapi:switch", nss)
                    for switch in switchList:
                        myvalue = switch.get("value")
                        myobject = switch.get("object")
                        myswitch = TapiSwitch(myvalue, myobject)
                        myparam.addSwitch(myswitch)
                else:
                    self.dealDisableTrue(param)

            mapList = itf.findall("./tapi:map", nss)
            for map in mapList:
                object = map.get("object")
                prefix = map.get("prefix")
                curMap = TapiMap(object, prefix)
                paramList = map.findall("./tapi:param", nss)
                for param in paramList:
                    disable = param.get("disable")
                    if disable is None or disable == "FALSE":
                        objs = curMap.getObjects()
                        prefixs = curMap.getPrefixes()
                        index = 0
                        pname = param.get("name")
                        palias = param.get("alias")
                        tValue = param.findall("./tapi:value", nss)
                        for element in objs:
                            myname = pname.replace("$object$", element)
                            myalias = cur.auto_prefix + prefixs[index] + palias
                            myparam = TapiParam(myname, myalias)
                            if len(tValue) > 0:
                                for v in tValue:
                                    myparam.input = v.get("input")
                                    myparam.output = v.get("output")
                            index += 1
                            myele = element.lower()
                            xls = GetMappedClsFunc(self.pluginName, myele)
                            if isinstance(xls, MetaClass):
                                xls.addParam(myparam)
                            else:
                                mye1 = re.sub('.*\.', "", myele)
                                xls1 = GetMappedClsFunc(self.pluginName, mye1)
                                xls = xls1.clone(element, self)
                                xls.addParam(myparam)
                                MetaClassManager.addMetaClass(xls)
                                replace_map[myele] = mye1
                    else:
                        self.dealDisableTrue(param, curMap)


if __name__ == '__main__':
    import sys
    import os
    import platform
    if len(sys.argv) > 1:
        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")
        p2 = MetaClassParser()
        p2.read_xml("stcFramework.processed.xml")
        #p3 = MetaClassParser()
        #p3.read_xml("stcMcastCore.processed.xml")

        pb = MetaClassParser()
        pb.read_xml("stcRoutingCore.processed.xml")
        
        p4 = MetaClassParser()
        p4.read_xml("stcIsis.processed.xml")
       
        p5 = MetaClassParser()
        p5.read_xml("stcOspfv2.processed.xml")
               
        p6 = MetaClassParser()
        p6.read_xml("stcRsvp.processed.xml")
        
        p7 = MetaClassParser()
        p7.read_xml("stcLdp.processed.xml")

        pa = MetaClassParser()
        pa.read_xml("stcRoutingWizard.processed.xml")
            
        p = MetaClassParser()
        p.read_xml("stcVpn.processed.xml")

        t = TapiInfoParser()
        t.read_xml("stcVpn.tapi.xml")

        p.buildTapiInfo(t)
        p.printTapiTree(t)
        p.printTapiDataXml(t)
    else:
        if platform.system().startswith('Windows'):
            path = '..\\..\\..\\..\\UnitTest\\'
        else:
            path = './/'

        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")
        p = MetaClassParser()
        p.read_xml("stcPcep.processed.xml")

        myfile = file("testtapi.txt", 'w')

        mapping = MetaClassManager.getClassMapping(p.pluginName)
        MetaClassManager.printDictToFile(myfile, mapping)

        t = TapiInfoParser()
        t.read_xml("stcPcep.tapi.xml")

        str = '::sth::emulation_pcep_config'
        tdict = TapiInfoParser.interfaceDict[str].getRetDict()
        print >> myfile, tdict

        p.printTapiInfoToFile(t, myfile)
        myfile.close()

        file_object = open('testtapi.txt')
        all_the_text = file_object.read()
        file_object.close()

        curPath = os.path.dirname(__file__)
        fileName = os.path.join(curPath, path + 'testtapi_expected.txt')

        file_object_cmp = open(fileName)
        all_the_text_cmp = file_object_cmp.read()
        file_object_cmp.close()

        # assert all_the_text_cmp == all_the_text

    print "end"
