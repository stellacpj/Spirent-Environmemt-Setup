import re
import sys
import os
import copy
import platform
import xml.etree.cElementTree as ET
from tapiclass import TapiParam, TapiItem, TapiInterface

nss = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}
ET.register_namespace('stc', 'urn:www.spirentcom.com:XMLSchema.xsd')


class CanSaveAs:
    save = 0
    skip = 1
    save_next = 2
    save_split = 3


class MetaClass:

    def __init__(self, packageName, baseName, pluginName, name, id, canCreate):
        self.packageName = packageName
        self.baseName = baseName
        self.pluginName = pluginName
        self.name = name
        self.id = id
        self.canCreate = canCreate
        self.relationDict = {}
        self.propertyDict = {}
        self.paramDict = {}
        self.aliasDict = {}
        self.saveAsScript = ""
        self.classCondition = {}
        self.enumDict = {}
        self.keySwitchDict = {}

    def getName(self):
        return self.name

    def getAliasDict(self):
        return self.aliasDict

    def getParamDict(self):
        return self.paramDict

    def getPropertyDict(self):
        return self.propertyDict

    def setProperty(self, propertyName, MetaProperty):
        self.propertyDict[propertyName.lower()] = MetaProperty

    def getEnumDict(self):
        return self.enumDict

    def isCreatable(self):
        if self.canCreate == 'false':
            return False
        return True

    def setCanCreate(self, cancreate):
        self.canCreate = cancreate

    def addMetaEnum(self, metaEnum):
        self.enumDict[metaEnum.getName()] = metaEnum

    def getId(self):
        return self.id

    def getPluginName(self):
        return self.pluginName

    def getBaseClass(self):
        return self.baseName

    def getBaseChildren(self):
        mapFunc = MetaClassManager.getMappedClass
        baseChildren = ""
        relationClsList = self.getRelationCls("baseChild")
        for el, element in relationClsList.items():
            cls = element.getClassRef().lower()
            baseChildren += cls + " "
            mappedCls = mapFunc(self.pluginName, cls)
            if isinstance(mappedCls, MetaClass):
                eBase = mappedCls.getBaseChildren()
                if eBase != "":
                    baseChildren += eBase + ""
        return baseChildren

    def getRelationParam(self):
        relationParam = ""
        for key in self.paramDict.keys():
            result = re.match(r"(.*)\-(.*)", key)
            if result is not None:
                relationParam += key + " "
        return relationParam

    def getParentClassName(self):
        parentName = ""
        relationClsList = self.getRelationCls("parent")
        for key, element in relationClsList.items():
            if element.classRefEx.pluginName != self.pluginName:
                parentName += element.classRefEx.pluginName +"."
            parentName += element.getClassRef() + " "
        return parentName

    def isChildof(self, pname):
        parent = self.getParentClassName()
        if re.search(pname, parent, flags=re.I) is not None:
            return True
        base = MetaClassManager.getMappedClass(self.pluginName, self.baseName)
        if isinstance(base, MetaClass):
            return base.isChildof(pname)
        return False
                       
    def getClassCondition(self):
        return self.classCondition

    def isCollectionParam(self, aliasKey):
        if aliasKey in self.aliasDict:
            if self.aliasDict[aliasKey].maxOccurs != str(1):
                if not self.isExistChildOfParents():
                    return True
        return False

    def isExistChildOfParents(self):
        relationType = "parent"
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                elCls = self.relationDict[relationType][element]
                if (elCls.minOccurs != elCls.maxOccurs or
                        elCls.minOccurs != '1'):
                    return False
        return True

    def isExistChildOf(self, parent):
        classRef = re.sub('[0-9]*$', '', parent)
        if 'parent' in self.relationDict:
            for el in self.relationDict['parent']:
                elCls = self.relationDict['parent'][el]
                ret = re.search(classRef, elCls.classRefEx.name, flags=re.I)
                if ret is not None:
                    if (elCls.minOccurs == elCls.maxOccurs
                        and elCls.minOccurs == '1'):
                        return True
        return False

    def clone(self, newname, parser = ""):
        if parser == "":
            pluginName = self.pluginName
            packageName = self.packageName
        else:
            pluginName = parser.pluginName
            packageName = parser.packageName
        other = MetaClass(packageName, self.baseName, pluginName,
                        newname, self.id, self.canCreate)        
        other.relationDict = self.relationDict.copy()
        other.propertyDict = self.propertyDict.copy()
        other.enumDict = self.enumDict.copy()
        other.saveAsScript = ""
        other.paramDict = copy.deepcopy(self.paramDict)
        other.aliasDict = copy.deepcopy(self.aliasDict)       
        for el, element in other.paramDict.items():
            element.obj = newname
        other.classCondition = {}
        return other

    def removeProp(self, prop):
        if prop in self.propertyDict:
            self.propertyDict.__delitem__(prop)

    def setupRelation(self, rel):
        reli = rel.get("isInternal")
        if reli == "true":
            return
        reld = rel.get("dstClassRef")
        rels = rel.get("srcClassRef")
        reld = re.sub(r".*\.", "", reld)
        rels = re.sub(r".*\.", "", rels)
        result = re.match(r"(.*)\.(.*)", rels)
        if result is not None:
            parent = result.group(1).lower()
        if reld == self.name:
            relCls = rels
        else:
            relCls = reld
        mycls = MetaClassManager.getMappedClass(self.pluginName, relCls)
        mymetaRel = MetaClassCustomRel.createInstance(rel.get("type"),
                                                      mycls,
                                                      rel.get("maxOccurs"),
                                                      rel.get("minOccurs"))
        return mymetaRel.buildRelation(rels, reld, self)
    
    def setupBaseCls(self):
        classkey = self.baseName.lower()
        mapFunc = MetaClassManager.getMappedClass
        mapCls = mapFunc(self.pluginName, classkey)
        if isinstance(mapCls, MetaClass):
            mapCls.addBaseChildRelations(self)
            if mapCls.pluginName != self.pluginName:       
                mapCls.copyProperties_baseChild()
                mapCls.setupRelationForBaseCls()
    
    def copyProperties_baseChild(self):
        for key, value in self.relationDict.items():
            if key == "baseChild":
                for el, baseChildRel in value.items():
                    self.copyProperties(baseChildRel.classRefEx)
                    baseChildRel.classRefEx.copyProperties_baseChild()

    def setupRelationForBaseCls(self):
        for key, value in self.relationDict.items():
            if key == "baseChild":
                for el, baseChildRel in value.items():
                    mybase_child = baseChildRel.classRefEx
                    self.copyRelations(mybase_child)
            
    def addAlias(self, alias, property, isBase=False):
        myel = ""
        for el in self.aliasDict:
            if self.aliasDict[el].isEqualProp(property):
                myel = el
        if myel != "":
            self.aliasDict.pop(myel)
        # splitName = MetaClassManager.splitName(property.name)
        # if alias != splitName and re.search("-", property.name) == None:
        #    print "The param's definition in tapi.xml may be wrong:"
        #    print "\t" + self.name + "." + property.name
        self.aliasDict[alias] = property

    def setRelation_basechild(self, cls, func, type1='child', type2='parent'):
        basechild_relations = self.getRelationCls("baseChild")
        for el, element in basechild_relations.items():
            myelem = element.classRefEx
            if type1 != "":
                addrel1 = func(type1, cls)
                myelem.setRelation(addrel1.getType(), addrel1)
            if type2 != "":
                addrel2 = func(type2, myelem)
                cls.setRelation(addrel2.getType(), addrel2)
            myelem.setRelation_basechild(cls, func, type1, type2)

    def addBaseChildRelations(self, childCls):
        addrelation = MetaClassCustomRel.createInstance("baseChild", 
                                                        childCls, 1, 1)
        self.setRelation("baseChild", addrelation)

    def setRelation(self, relationType, relationCls):
        relationClsList = {}
        if relationType in self.relationDict:
            relationClsList = self.relationDict[relationType]
        key = relationCls.classRefEx.name.lower()
        if key not in relationClsList:
            key = relationCls.classRefEx.name.lower()
            relationClsList[key] = relationCls
            self.relationDict[relationType] = relationClsList 

    def copyProperties(self, other):
        for key, value in self.propertyDict.items():
            other.propertyDict[key] = value

    def copyRelations(self, baseChild):
        for key, value in self.relationDict.items():
            if (key == "parent" and self.pluginName != "vpn"
                and self.pluginName != "rtgwizard"):
                for el, parentRel in value.items():
                    myparent = parentRel.classRefEx
                    cloneFunc = parentRel.cloneRelationBy
                    addrelation = cloneFunc("child", baseChild)
                    if addrelation is not None:
                        myparent.setRelation(addrelation.getType(), addrelation)
                        parent_rel_t = parentRel.getType()
                        baseChild.setRelation(parent_rel_t, parentRel)
                    baseChild.setRelation_basechild(myparent, cloneFunc,
                                                  'parent', 'child')
                    myparent.setRelation_basechild(baseChild, cloneFunc)
                    myparent.setRelation_basechild(self, cloneFunc)
            elif key == "child":
                for el, childRel in value.items():
                    mychild = childRel.classRefEx
                    cloneFunc = childRel.cloneRelationBy
                    addrelation = cloneFunc("parent", baseChild)
                    if addrelation is not None:
                        mychild.setRelation(addrelation.getType(), addrelation)
                        child_rel_t = childRel.getType()
                        baseChild.setRelation(child_rel_t, childRel)  
                    baseChild.setRelation_basechild(mychild, cloneFunc,
                                                    'child', 'parent') 
                    mychild.setRelation_basechild(baseChild, cloneFunc,
                                                  'parent', 'child')
                    mychild.setRelation_basechild(self, cloneFunc,
                                                  'parent', 'child')
            elif key != "baseChild" and key != "parent":
                for el, element in value.items():
                    cls = element.classRefEx
                    type = element.getType()
                    cloneFunc = element.cloneRelationBy
                    baseChild.setRelation(type, element)
                    baseChild.setRelation_basechild(cls, cloneFunc, '', type) 
                    cls.setRelation_basechild(baseChild, cloneFunc, '', type)
                    cls.setRelation_basechild(self, cloneFunc, '', type)

    def getRelationCls(self, relationType):
        if relationType in self.relationDict:
            return self.relationDict[relationType]
        return {}

    def findRelationClsBy(self, relationType, classRef):
        element_list = []
        if relationType in self.relationDict:
            for el, element in self.relationDict[relationType].items():
                if element.classRefEx.name == classRef:
                    element_list.append(element)
        if len(element_list) > 0:
            return element_list
        return None

    def addParam(self, myParam, bind=None):
        myprop = myParam.getProp()
        mapFunc = MetaClassManager.getMappedClass
        self.paramDict[myprop.lower()] = myParam
        property1 = None
        if myprop.lower() in self.propertyDict:
            property1 = self.propertyDict[myprop.lower()]
            alias = myParam.getAlias()
            prop = self.propertyDict[myprop.lower()]
            self.addAlias(alias, prop)
        else:
            myprop1 = re.sub("\-.*", "", myprop).lower()
            if myprop1 in self.relationDict:
                relation1 = self.relationDict[myprop1]
                for el, rel_value in relation1.items():
                    property1 = MetaProperty(myprop.lower(),
                                             rel_value.getMaxOccurs(),
                                             rel_value.getMinOccurs(),
                                             "", bind)
                    self.propertyDict[myprop.lower()] = property1
                    self.addAlias(myParam.getAlias(), property1)
                if myprop1 is not None:
                    self.saveAsScript = "wait"
            elif bind is not None:
                cls2 = mapFunc(self.pluginName, bind.object2)
                if myprop1 in cls2.relationDict:
                    rel = cls2.relationDict[myprop1]
                    for el, rel_value in rel.items():
                        property1 = MetaProperty(myprop.lower(),
                                                 rel_value.getMaxOccurs(),
                                                 rel_value.getMinOccurs(),
                                                 "", bind)
                        self.propertyDict[myprop.lower()] = property1
                        self.addAlias(myParam.getAlias(), property1)
                        cloneFunc = rel_value.cloneRelationBy
                        addrel = cloneFunc(myprop1, cls2)
                        self.setRelation(addrel.relationType, addrel)
                    cls2.relationDict.pop(myprop1)
                    if myprop1 is not None:
                        self.saveAsScript = "wait"
        if "baseChild" in self.relationDict:
            if property1 is not None:
                for el, element in self.relationDict["baseChild"].items():
                    myelem = element.getClassRef()
                    myprop = myprop.lower()
                    alias = myParam.getAlias()
                    elCls = mapFunc(self.pluginName, myelem)
                    elCls.propertyDict[myprop] = property1
                    elCls.addAlias(alias, property1, True)
                    elCls.paramDict[myprop] = myParam
        if (re.match('.*\.', self.name) is not None and
                "parent" in self.relationDict):
            for el, element in self.relationDict["parent"].items():
                pelem = element.getClassRef()
                pelCls = mapFunc(self.pluginName, pelem)
                if (isinstance(pelCls, MetaClass) and
                        re.match(pelem, self.name, flags=re.I) is not None):
                    myname = re.sub('.*\.', "", self.name).lower()
                    if "child" in pelCls.relationDict:
                        childDict = pelCls.relationDict["child"]
                        if myname in childDict:
                            cloneFunc = childDict[myname].cloneRelationBy
                            one = cloneFunc("child", self)
                            pelCls.setRelation("child", one)
                            childDict.pop(myname)

    def buildup(self, tParser, tInterface):
        mapFun = MetaClassManager.getMappedClass
        if tInterface.b_all_props == "TRUE":
            for key, value in self.propertyDict.items():
                if key not in self.paramDict:
                    alias = MetaClassManager.splitName(value.getName())
                    myParam = TapiParam(self.name + "."+key,
                                        tInterface.auto_prefix + alias)
                    self.paramDict[key] = myParam
                    self.addAlias(tInterface.auto_prefix + alias, value)
        for key, value in self.relationDict.items():
            if (key != "baseChild" and key != "child" and key != "parent"):
                for el, element in value.items():
                    dstRefName = element.getClassRef()
                    clsRef = mapFun(self.pluginName, dstRefName)
                    for pname, param in clsRef.paramDict.items():
                        myprop = re.sub("\-.*", "", param.getProp())
                        if key == myprop:
                            prop = param.getProp().lower()
                            property1 = MetaProperty(prop,
                                                     element.getMaxOccurs(),
                                                     element.getMinOccurs(),
                                                     "")
                            alias = param.getAlias()
                            clsRef.propertyDict[prop] = property1
                            clsRef.addAlias(alias, property1)

                            # check if parent.obj in the mapping, if it is,
                            # need to also update the parent.obj
                            parentAddClsRef = ''
                            relationDict = clsRef.relationDict
                            if 'parent' in relationDict:
                                ParentDict = relationDict['parent']
                                for el, myparent in ParentDict.items():
                                    parent = myparent.getClassRef()
                                    nRef = parent + '.' + dstRefName
                                    dCls = mapFun(self.pluginName, nRef)
                                    if isinstance(dCls, MetaClass):
                                        dCls.propertyDict[prop] = property1
                                        dCls.addAlias(alias, property1)
                            relationDict = clsRef.relationDict
                            if "baseChild" in relationDict:
                                relDict = relationDict["baseChild"]
                                for el, basechild in relDict.items():
                                    dstref = basechild.getClassRef()
                                    dstref = dstref.lower()
                                    dRef = mapFun(self.pluginName, dstref)
                                    if isinstance(dRef, MetaClass):
                                        pD = dRef.propertyDict
                                        aliasD = dRef.aliasDict
                                        paramD = dRef.paramDict
                                        a = param.getAlias()
                                        pD[param.getProp().lower()] = property1
                                        dRef.addAlias(a, property1)
                                        paramD[pname] = param
        for key, value in self.paramDict.items():
            result = re.match(r"(.*)\-(.*)", key)
            if result is not None:
                self.saveAsScript = "wait"
                tAlias = tInterface.auto_prefix + value.alias
                if tAlias not in self.aliasDict:
                    tPproperty = MetaProperty(value.prop, 1, 1, "")
                    self.addAlias(tAlias, tPproperty)     
            if len(value.switchDict) > 0:
                self.keySwitchDict[value.alias] = value
        tapiClsList = tParser.getTapiClsList()
        if self.name.lower() in tapiClsList:
            clsCond = tapiClsList[self.name.lower()].getClsConditon()
            if len(clsCond) > 0:
                self.classCondition = clsCond

    def buildPrintTapiTree(self, tParser, tInterface,
                           table_dict, print_str, tapi_dict):
        clsItems = {}
        if self.canCreate == 'false':
            return print_str

        parents = self.getParentClassName()
        for p in parents.split(" "):
            if MetaClassManager.isConfigClass(self.name, p) is False:
                self.canCreate = "false"
                return print_str

        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)

        if result is None:
            self.buildup(tParser, tInterface)
            prefix = tInterface.auto_prefix
            print_str = self.printTable(prefix, table_dict,
                                        print_str, tapi_dict)
            for key, relations in self.relationDict.items():
                if key == "child":
                    for el in relations:
                        myitems = relations[el].buildTapiRelInfo(self.name)
                        if myitems.__len__() > 0:
                            keyList = myitems.keys()
                            keyListSorted = sorted(keyList)
                            for obj in keyListSorted:
                                value = myitems[obj]
                                value.buildup(tParser, tInterface)
                                print_str = value.printTable(prefix,
                                                             table_dict,
                                                             print_str,
                                                             tapi_dict)
        return print_str

    def setupTapiInfo(self):
        clsItems = {}
        if self.canCreate == 'false':
            return clsItems

        parents = self.getParentClassName()
        for p in parents.split(" "):
            if MetaClassManager.isConfigClass(self.name, p) is False:
                self.canCreate = "false"
                return clsItems

        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)

        if result is None:
            clsItems[self.id + self.name] = self
            for key, value in self.relationDict.items():
                if key == "child":
                    for el, element in value.items():
                        myitems = element.buildTapiRelInfo(self.name)
                        if myitems.__len__() > 0:
                            merge_dict = MetaClassManager.merge_dict_recursive
                            clsItems = merge_dict(clsItems, myitems)
        return clsItems

    def canSaveAs(self, pobjDict, objDict):
        mapping = MetaClassManager.getClassMapping(self.pluginName)
        if self.canCreate == "false":
            return CanSaveAs.skip
        if self.saveAsScript == "":
            return CanSaveAs.save
        if self.saveAsScript == "wait":
            ret = CanSaveAs.save
            relationParams = self.getRelationParam()
            for prop in relationParams.split():
                if prop in objDict:
                    ret = CanSaveAs.save_next
                    pclassname = objDict['parent']
                    if not self.isExistChildOf(pclassname):
                        ret = CanSaveAs.save_split
                    break
            if len(self.classCondition) > 0:
                for key, cond in self.classCondition.items():
                    myprop = re.sub(".*\.", "", key)
                    myvalue = pobjDict[myprop]
                    if not cond.IsPass(myvalue):
                        return CanSaveAs.skip
            return ret
        return CanSaveAs.skip

    def isInParentRelation(self, curcls):
        if 'parent' in self.relationDict:
            parents = self.relationDict['parent']
            for p in parents:
                if parents[p].classRefEx == curcls.classRefEx:
                    return True
        return False

    def printMetaToFile(self, f):
        print >> f, (self.name, self.baseName)
        # print (self.name, hex(self.id), self.baseName)
        for key, value in self.propertyDict.items():
            value.printMetaToFile(f)
        for key, value in self.relationDict.items():
            print >>f, "\tRelation:" + key
            for el, element in value.items():
                element.printMetaToFile(f)

    def printMeta(self):
        print (self.name, self.baseName)
        keys = self.propertyDict.keys() 
        keys.sort() 
        for key in keys:
            self.propertyDict[key].printMeta()
        for key, value in self.relationDict.items():
            print "\tRelation:" + key
            for el, element in value.items():
                element.printMeta()

    def printTree(self, parent):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            info_str = self.name + " -baseclass " + self.baseName
            MetaClassManager.printIndent(info_str)
            #info_str = "\tproperties: "
            #for key, value in self.propertyDict.items():
            #    info_str += value.getProperty() + " "
            #MetaClassManager.printIndent(info_str)
            if (parent is not None and
                 (parent.name == self.name
                 or parent.baseName == self.baseName
                 or parent.name == self.baseName
                 or parent.baseName == self.name
                 or self.baseName == parent.pluginName+"."+parent.name
                 or parent.baseName == self.pluginName+"."+self.name)):
                return
            for key, value in self.relationDict.items():
                if key == "child":
                    MetaClassManager.indent += 1
                    for el, element in value.items():
                        if self.isInParentRelation(element):
                            continue
                        element.printTree(self)
                    MetaClassManager.indent -= 1

    def printXml(self, parent, label="xtapi:class", str_other=""):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            str_info ="<" + label + " name=\"" + self.name + "\" baseclass=\""
            str_info += self.baseName +"\" " + str_other + ">"
            MetaClassManager.printIndent(str_info)
            if (parent is not None and
                 (parent.name == self.name
                 or parent.baseName == self.baseName
                 or parent.name == self.baseName
                 or parent.baseName == self.name
                 or self.baseName == parent.pluginName+"."+parent.name
                 or parent.baseName == self.pluginName+"."+self.name)):
                str_info = "</" + label + ">"
                MetaClassManager.printIndent(str_info)
                return
            for key, value in self.relationDict.items():
                if key == "child":
                    MetaClassManager.indent += 1
                    for el, element in value.items():
                        if self.isInParentRelation(element):
                            continue
                        element.printXml(self)
                    MetaClassManager.indent -= 1
            str_info = "</" + label + ">"
            MetaClassManager.printIndent(str_info)
    
    def printTapiDataXml(self, parent, auto_prefix):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            for key, value in self.paramDict.items():
                str_alias = re.sub("^"+ auto_prefix, "", value.alias)
                myparam = self.name + "." + key
                str_info = "<tapi:param " + " name=\"" + myparam + "\""
                str_info += " alias=\"" + str_alias + "\"/>"
                MetaClassManager.printIndent(str_info)
            if (parent is not None and
                 (parent.name == self.name
                 or parent.baseName == self.baseName
                 or parent.name == self.baseName
                 or parent.baseName == self.name)):
                return
            for key, value in self.relationDict.items():
                if key != "parent" and key != "baseChild":
                    MetaClassManager.indent += 1
                    for el, element in value.items():
                        if self.isInParentRelation(element):
                            continue
                        element.classRefEx.printTapiDataXml(self, auto_prefix)
                    MetaClassManager.indent += 1
            
    def printTreeOccurs(self, maxOccurs, minOccurs):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            if minOccurs != "1" or maxOccurs != "1":
                MetaClassManager.printIndent(" + " + self.name + "[" +
                                             minOccurs + "-" + maxOccurs + "]")

    def printTable(self, auto_prefix, table_dict, print_str, tapi_dict):
        for key, value in self.aliasDict.items():
            str_key = re.sub("^"+auto_prefix, "", key)
            if key in table_dict:
                if re.search(self.name, table_dict[key]) is None:
                    print_str = re.sub(str_key + "\t\t\t\t" +
                                       table_dict[key] + "\t",
                                       str_key + "\t\t\t\t" +
                                       table_dict[key] + "," +
                                       self.name + "\t", print_str)
                    table_dict[key] = table_dict[key]+","+self.name
                    tapi_dict[key].addObj(key, self.name)
            else:
                print_str = str(print_str + str_key + "\t\t\t\t" + self.name +
                                "\t\t\t\t" + value.getName() +
                                "\t\t\t\t" + value.getDefaultValue() + "\n")
                table_dict[key] = self.name
                item = TapiItem(key, self.name, value.getName())
                tapi_dict[key] = item
        return print_str


class MetaEnum:
    def __init__(self, name):
        self.name = name
        self.enumDict = {}

    def getName(self):
        return self.name

    def addEnum(self, name, value):
        self.enumDict[name] = value

    def getEnumValue(self, name, value):
        return self.enumDict[name]


class MetaRelation:

    def __init__(self, relationType, classRefEx, maxOccurs, minOccurs):
        self.relationType = relationType
        self.classRefEx = classRefEx
        self.maxOccurs = maxOccurs
        self.minOccurs = minOccurs

    def getName(self):
        return self.name

    def getMaxOccurs(self):
        return self.maxOccurs

    def getMinOccurs(self):
        return self.minOccurs

    def getType(self):
        return self.relationType

    def setType(self, newType):
        self.relationType = newType

    def getClassRef(self):
        if isinstance(self.classRefEx, MetaClass):
            return self.classRefEx.name.lower()
        else:
            return self.classRefEx

    def isEqual(self, other):
        if (self.relationType == other.relationType and
                self.classRefEx == other.classRefEx and
                self.maxOccurs == other.maxOccurs and
                self.minOccurs == other.minOccurs):
            return True
        return False
    
    def cloneRelationBy(self, type, cloneClass):
        other = MetaRelation(type, cloneClass, self.maxOccurs, self.minOccurs)
        return other

    def buildTapiRelInfo(self, parent):
        clsname = self.getClassRef()
        newname = parent.lower() + "." + clsname
        plugin = self.classRefEx.pluginName
        cls = MetaClassManager.getMappedClass(plugin, newname)
        if isinstance(cls, str):
            cls = MetaClassManager.getMappedClass(plugin, clsname)
        if isinstance(cls, MetaClass):
            return cls.setupTapiInfo()
        return []

    def printMetaToFile(self, f):
        mystr = str("\t\t" + self.classRefEx.name)
        print >> f, mystr

    def printMeta(self):
        print str("\t\t" + self.classRefEx.name)

    def printTree(self, parent):
        self.classRefEx.printTree(parent)
        self.classRefEx.printTreeOccurs(self.maxOccurs, self.minOccurs)
    
    def printXml(self, parent):
        label = self.relationType
        str_info = "minOccurs=\"" + self.minOccurs
        str_info += "\" maxOccurs=\"" + self.maxOccurs + "\""
        self.classRefEx.printXml(parent, label, str_info)

class MetaClassCustomRel(MetaRelation):
    
    def __init__(self, relationType, classRef, maxOccurs, minOccurs):
        MetaRelation.__init__(self, relationType.lower(), classRef,
                              maxOccurs, minOccurs);

    @classmethod
    def createInstance(self, relationType, classRef,
                       maxOccurs, minOccurs):
        if relationType == 'framework.ParentChild':
            return MetaClassParentRel(relationType, classRef,
                                      maxOccurs, minOccurs)
        if relationType == 'child':
            return MetaClassChildRel(relationType, classRef,
                                      maxOccurs, minOccurs)
        if relationType == 'baseChild':
            return MetaClassBaseChildRel(relationType, classRef,
                                      maxOccurs, minOccurs)
        return MetaClassCustomRel(relationType, classRef,
                                 maxOccurs, minOccurs)
    
    def buildRelation(self, rels, reld, curCls):
        red = re.search(curCls.name, reld, flags=re.I)
        res = re.search(curCls.name, rels, flags=re.I)
        if red is not None:
            curCls.setRelation(self.relationType, self)
        else:
            cloneFunc = self.cloneRelationBy
            addrelation = cloneFunc(self.relationType, curCls)
            self.classRefEx.setRelation(addrelation.relationType, addrelation)

        
class MetaClassParentRel(MetaClassCustomRel):
    def __init__(self, relationType, classRef, maxOccurs, minOccurs):
        MetaClassCustomRel.__init__(self, relationType, classRef,
                              maxOccurs, minOccurs);
        self.relationType = 'parent'
        
    
    def buildRelation(self, rels, reld, curCls):
        cloneFunc = self.cloneRelationBy
        MetaClassCustomRel.buildRelation(self, rels, reld, curCls)
        red = re.search(curCls.name, reld, flags=re.I)
        res = re.search(curCls.name, rels, flags=re.I)
        if red is not None:
            tcls = MetaClassManager.getMappedClass(curCls.pluginName, rels)
            if isinstance(tcls, MetaClass):
                addrelation = cloneFunc("child", curCls)
                if addrelation is not None:
                    tcls.setRelation(addrelation.getType(), addrelation)     
        if res is not None:
            reldcls = MetaClassManager.getMappedClass(curCls.pluginName, reld)
            if isinstance(reldcls, MetaClass):
                childrel = cloneFunc("child", reldcls)
                tcls = MetaClassManager.getMappedClass(curCls.pluginName, rels)
                if isinstance(tcls, MetaClass):
                    tcls.setRelation(childrel.relationType, childrel)

    def cloneToChildRel(self, dstClassRef):
        other = MetaClassChildRel(self.relationType, dstClassRef,
                             self.maxOccurs, self.minOccurs)
        return other


class MetaClassChildRel(MetaClassCustomRel):
    def __init__(self, relationType, classRef, maxOccurs, minOccurs):
        MetaClassCustomRel.__init__(self, relationType, classRef,
                              maxOccurs, minOccurs);
        self.relationType = 'child'


class MetaClassBaseChildRel(MetaClassCustomRel):
    def __init__(self, relationType, classRef, maxOccurs, minOccurs):
        MetaClassCustomRel.__init__(self, relationType, classRef,
                              maxOccurs, minOccurs);
        self.relationType = 'baseChild'
        self.maxOccurs = 1
        self.minOccurs = 1


class MetaProperty:

    def __init__(self, name, maxOccurs, minOccurs, value, bind=None):
        self.name = name
        self.maxOccurs = maxOccurs
        self.minOccurs = minOccurs
        self.defaultValue = value
        self.bind = bind

    def isEqualProp(self, other):
        if self.name == other.name:
            if self.maxOccurs == other.maxOccurs:
                if self.minOccurs == other.minOccurs:
                    if self.defaultValue == other.defaultValue:
                        return True
        return False

    def getName(self):
        return self.name

    def getDefaultValue(self):
        return self.defaultValue

    def getMaxOccurs(self):
        return self.maxOccurs

    def printMetaToFile(self, f):
        MetaClassManager.printIndentToFile(
            "\tProperty:" + (self.name) + "," + self.defaultValue, f)

    def printMeta(self):
        MetaClassManager.printIndent(
            "\tProperty:" + (self.name) + "," + self.defaultValue)

    def getProperty(self):
        if self.minOccurs == "1" and self.maxOccurs == "1":
            return "-" + (self.name) + " " + self.defaultValue
        return str("-" + (self.name) + " \"" + self.defaultValue + " [" +
                   self.minOccurs + "-" + self.maxOccurs + "]\"")


class MetaClassManager:
    pluginClsMap = {}
    mapping = {}
    skipClsList = {"framework.Result": "framework.Result",
                   "framework.Command": "framework.Command",
                   "RsvpStateSummary": "RsvpStateSummary"}
    indent = 0
    
    @staticmethod
    def getClassMapping(plugin):
        myplug = plugin.lower()
        if myplug in MetaClassManager.pluginClsMap:
            MetaClassManager.mapping =  MetaClassManager.pluginClsMap[myplug]
        return MetaClassManager.mapping

    @staticmethod
    def getMappedClass(pluginName, pluginClsKey = None):
        if isinstance(pluginClsKey, str):
            plugin = pluginName
            clsnm = pluginClsKey.lower()
            result = re.match(r"(.*)\.(.*)", pluginClsKey)
            if result is not None:
                parent = result.group(1).lower()
                parent = re.sub(r".*\.", "", parent)
                if parent in MetaClassManager.pluginClsMap:
                    plugin = parent
                    clsnm = result.group(2).lower()
            mapping = {}
            if plugin in MetaClassManager.pluginClsMap:
                mapping = MetaClassManager.pluginClsMap[plugin]
            if clsnm in mapping:
                return mapping[clsnm]
            for key in MetaClassManager.pluginClsMap:
                if clsnm in MetaClassManager.pluginClsMap[key]:
                    return MetaClassManager.pluginClsMap[key][clsnm]
        else:
            clsnm = pluginClsKey.name.tolower()
            mapping = MetaClassManager.getClassMapping(pluginName)
            if clsnm in mapping:
                return mapping[clsnm]
        return pluginClsKey
        
    @staticmethod
    def printDictToFile(f, mapping):
        keyList = mapping.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = mapping[obj]
            value.printMetaToFile(f)

    @staticmethod
    def printDict(mapping):
        keyList = mapping.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = mapping[obj]
            value.printMeta()

    @staticmethod
    def printIndentToFile(msg, f):
        indent_str = ""
        for i in range(0, MetaClassManager.indent):
            indent_str += "\t"
        print >> f, indent_str + msg

    @staticmethod
    def printIndent(msg):
        indent_str = ""
        for i in range(0, MetaClassManager.indent):
            indent_str += "\t"
        print indent_str + msg

    @staticmethod
    def isConfigClass(clsname, chkclsname):
        if chkclsname not in MetaClassManager.skipClsList:
            if clsname not in MetaClassManager.skipClsList:
                return True
        MetaClassManager.skipClsList[clsname] = clsname
        return False

    @staticmethod
    def printTapiTable(pluginName, mapping):
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        for key, value in mapping.items():
            if pluginName == value.getPluginName():
                value.printTable(table_dict, print_str, tapi_dict)

    @staticmethod
    def addMetaClass(metacls):
        mymetacls = metacls.getName().lower()
        if metacls.pluginName in MetaClassManager.pluginClsMap:
            mapping = MetaClassManager.pluginClsMap[metacls.pluginName]
            if mymetacls in mapping:
                #print "err: duplicate MetaClass:" + metacls.getName()
                mapping[mymetacls] = metacls
            else:
                mapping[mymetacls] = metacls
        else:
            mapping = {}
            mapping[mymetacls] = metacls
            MetaClassManager.pluginClsMap[metacls.pluginName] = mapping

    @staticmethod
    def splitName(name):
        name_l = ""
        reobj = re.compile('([A-Z])')
        results = reobj.split(name)
        upper = ""
        upbk = ""
        for res in results:
            if (res == " " or res == ""):
                continue
            if (name_l == ""):
                name_l = res.lower()
                if res.isupper():
                    upbk += res
            else:
                if (res.isupper()):
                    upbk += res
                    if upper == "":
                        if len(upbk) == 1:
                            name_l = name_l + "_"
                        else:
                            name_l = name_l + res.lower()
                    else:
                        if len(upbk) == 1:
                            name_l = name_l + upper.lower()
                        else:
                            if name_l[-1] == upper.lower():
                                name_l = name_l + res.lower()
                            else:
                                name_l = name_l + upper.lower() + res.lower()
                    upper = res
                else:
                    if len(upbk) > 1:
                        index = len(name_l) - 1
                        name_l = name_l[:index] + "_" + name_l[-1]
                    else:
                        if upper != "":
                            name_l = name_l + upper.lower()
                    name_l = name_l + res
                    upper = ""
                    upbk = ""
        return name_l

    @staticmethod
    def merge_dict_recursive(a, b):
        '''recursively merges dict's. not just simple a['key'] = b['key'], if
        both a and bhave a key who's value is a dict then dict_merge is called
        on both values and the result stored in the returned dictionary.'''
        if not isinstance(b, dict):
            return b
        result = dict(a)
        if (sys.version.split(' ')[0]).split('.')[0] == '3':
            for k, v in b.items():
                if k in result and isinstance(result[k], dict):
                    tmp = MetaClassManager.merge_dict_recursive(result[k], v)
                    result[k] = tmp
                else:
                    result[k] = v
        else:
            for k, v in b.iteritems():
                if k in result and isinstance(result[k], dict):
                    tmp = MetaClassManager.merge_dict_recursive(result[k], v)
                    result[k] = tmp
                else:
                    result[k] = v
        return result

    
class Parser:

    def __del__(self):
        if os.path.exists('temp.xml'):
            os.remove('temp.xml')

    def read_xml(self, file):
        dom = self.Parse(file)
        return dom

    def Parse(self, fileName):
        dom = None
        try:
            if os.path.exists(fileName):
                dom = ET.parse(fileName)
            else:
                curPath = os.path.dirname(__file__)
                if platform.system().startswith('Windows'):
                    fName = os.path.join(curPath, '.\\model\\' + fileName)
                else:
                    fName = os.path.join(curPath, './/model//' + fileName)
                if os.path.exists(fName):
                    dom = ET.parse(fName)
                else:
                    stcInstallDir = os.environ['STC_INSTALL_DIR']
                    import zipfile
                    zfile = os.path.join(stcInstallDir, 'Resource.zip')
                    zf = zipfile.ZipFile(zfile, 'r')
                    fb = open('temp.xml', 'wb')
                    fb.write(zf.read('Model/' + fileName))
                    fb.close()
                    dom = ET.parse('temp.xml')
        except Exception:
            return dom
        return dom


class MetaClassParser(Parser):
    entryClassDict = {}

    def __init__(self, name=""):
        self.m_entryCls = []
        self.m_leftSrcRelation = {}
        self.m_leftDstRelation = {}
        self.relDict = []

    @staticmethod
    def isInEntryClassDict(clsCategory, className):
        for cls in MetaClassParser.entryClassDict[clsCategory]:
            ret = re.match(cls.name, className, flags=re.I)
            if cls.isCreatable() and cls.name == className:
                return True
        return False

    def appendToEntryByCheck(self, curCls):
        b_in = False
        for cls in self.m_entryCls:
            if cls == curCls:
                b_in = True
                break
        if b_in is False:
            reg = re.search("Port", curCls.name, flags=re.IGNORECASE)
            if reg is None:
                if (curCls.isChildof("project") is True or
                    curCls.isChildof('EmulatedDevice') is True):
                    self.m_entryCls.append(curCls)   
        for key, value in curCls.relationDict.items():
            if key == "baseChild":
                for el, baseChildRel in value.items():
                    self.appendToEntryByCheck(baseChildRel.classRefEx)

    def generateMetaCls(self, cls):
        clsn = cls.get("name")
        clsb = cls.get("baseClass")
        if MetaClassManager.isConfigClass(clsn, clsb) is True:
            clsc = cls.get("canCreate")
            clsid = cls.get("id")
            curCls = MetaClass(self.packageName,
                               clsb,
                               self.pluginName,
                               clsn,
                               clsid,
                               clsc)
            MetaClassManager.addMetaClass(curCls)
            
            if clsn == 'Ospfv2AuthenticationParams_':
                print "ok"
                
            relList = cls.findall("./stc:relation", nss)
            
            if len(relList) == 0:
                result = re.match(r"(.*)\.(.*)", clsb)
                if result is not None:
                    plugin_name = result.group(1)
                    if plugin_name != self.pluginName:
                        self.appendToEntryByCheck(curCls)

            for rel in relList:
                reld = rel.get("dstClassRef")
                rels = rel.get("srcClassRef")
                relt = rel.get("type")
                dcls = MetaClassManager.getMappedClass(self.pluginName, reld)
                scls = MetaClassManager.getMappedClass(self.pluginName, rels)
                if isinstance(dcls, MetaClass):
                    if isinstance(scls, MetaClass):
                        curCls.setupRelation(rel)
                    else:
                        self.relDict.append(rel)
                else:
                    self.relDict.append(rel)
                result = None
                if (relt == 'framework.ParentChild'):
                    result = re.match(r"(.*)\.(.*)", rels)
                    if result is not None:
                        plugin_name = result.group(1)
                        if plugin_name != self.pluginName:
                            self.appendToEntryByCheck(curCls)    
                elif (relt == 'routing.rtgcore.ResolvesInterface'):
                    continue
                else:
                    mycls = dcls
                    result = re.match(r"(.*)\.(.*)", reld)
                    if dcls == curCls:
                        mycls = scls
                        result = re.match(r"(.*)\.(.*)", rels)
                    if result is not None and isinstance(mycls, MetaClass):
                        plugin_name = result.group(1)
                        if plugin_name != self.pluginName:
                            self.appendToEntryByCheck(mycls)
                            
            propList = cls.findall("./stc:property", nss)
            for prop in propList:
                self.generateMetaProp(prop, curCls)

            enumList = cls.findall("./stc:enumeration", nss)
            for enum in enumList:
                self.generateMetaEnum(enum, curCls)
    
    def processRelDict(self):
        tmpDict = copy.deepcopy(self.relDict)
        for rel in tmpDict:
            reld = rel.get("dstClassRef")
            rels = rel.get("srcClassRef")
            relt = rel.get("type")
            dcls = MetaClassManager.getMappedClass(self.pluginName, reld)
            scls = MetaClassManager.getMappedClass(self.pluginName, rels)
            if isinstance(dcls, MetaClass):
                if isinstance(scls, MetaClass):
                    curCls = dcls
                    curCls.setupRelation(rel)
    
    def processForBaseCls(self):
        mapping = MetaClassManager.pluginClsMap[self.pluginName]
        for el, element in mapping.items():
            element.setupBaseCls()
        for el, element in mapping.items():            
            element.copyProperties_baseChild()
        for el, element in mapping.items():
            element.setupRelationForBaseCls()
  
    def generateMetaProp(self, prop, curCls):
        propd = prop.get("isDeprecated")
        if propd == "false":
            propi = prop.get("isInternal")
            propr = prop.get("isReadOnly")
            if propi == "false":
                if propr == "false":
                    propn = prop.get("name")
                    propx = prop.get("maxOccurs")
                    propo = prop.get("minOccurs")
                    propf = prop.get("default")
                    property = MetaProperty(propn, propx, propo, propf)
                    curCls.setProperty(property.getName(), property)

    def generateMetaEnum(self, enum, curCls):
        myenum = MetaEnum(enum.get("name"))
        curCls.addMetaEnum(myenum)
        subEnumList = enum.findall("./stc:enum", nss)
        for subenum in subEnumList:
            myenum.addEnum(subenum.get("name"), subenum.get("value"))

    def read_xml(self, file):
        dom = Parser.read_xml(self, file)
        self.pluginName = dom.getroot().get('plugin')
        self.packageName = dom.getroot().get('package')
        
        clsList = dom.getroot().findall("./stc:class", nss)
        for cls in clsList:
            clsr = cls.get("isReadOnly")
            clsi = cls.get("isInternal")
            if clsr == "false" and clsi == "false":
                self.generateMetaCls(cls)

        self.processRelDict()
        self.processForBaseCls()
        if len(self.m_entryCls) > 0:
            #for cls in self.m_entryCls:
            #    self.appendToEntryByCheck(cls)
            MetaClassParser.entryClassDict[self.pluginName] = self.m_entryCls

    def printTree(self):
        print "=========================="
        for element in self.m_entryCls:
            element.printTree(None)

    def printXml(self):
        print "=========================="
        for element in self.m_entryCls:
            element.printXml(None)

    def buildTapiInfo(self, tParser):
        clsItems = {}
        merge_dict_recursive = MetaClassManager.merge_dict_recursive
        for element in self.m_entryCls:
            interface = tParser.isInInterface(element.name)
            if interface is not None:
                myItems = element.setupTapiInfo()
                for key, value in myItems.items():
                    value.buildup(tParser, interface)
                clsItems = merge_dict_recursive(clsItems, myItems)
        return clsItems

    def printTapiDataXml(self, tParser):
        print "################################"
        for element in self.m_entryCls:
            interface = tParser.isInInterface(element.name)
            if interface is not None:
                element.printTapiDataXml(None, interface.auto_prefix)
            
    def printTapiTree(self, tParser):
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        for element in self.m_entryCls:
            interface = tParser.isInInterface(element.name)
            if interface is not None:
                print_str = element.buildPrintTapiTree(tParser, interface,
                                        table_dict, print_str, tapi_dict)
                print print_str
                self.outputTapiXml(tapi_dict, interface.auto_prefix)

    def outputTapiXml(self, tapiDict, auto_prefix):
        objDict = {}
        print_tapi = ""
        for el in tapiDict:
            str_el = re.sub("^"+ auto_prefix, "", el)
            value = tapiDict[el]
            objs = value.getStringofObjs().rstrip()
            if value.isMultiObj() is True:
                print_tapi += "<tapi:map object=\""
                print_tapi += objs
                print_tapi += "\" prefix=\"? ?\">\n\t"
                print_tapi += "<tapi:param name=\"$object$."
                print_tapi += value.attr + "\" alias=\"" + str_el + "\"/>\n"
                print_tapi += "</tapi:map>\n\n"
                for o in objs.split(" "):
                    if o not in objDict:
                        objDict[o] = o
            else:
                if objs not in objDict:
                    objDict[objs] = objs
        print_key = ""
        for obj in objDict:
            print_key += "<tapi:retkey name=\""
            print_key += obj.lower() + "_hnd\" object=\"" + obj + "\"/>\n"
        print print_key
        print print_tapi
        return "\r\n" + print_key + "\r\n" + print_tapi

    def printTapiInfo(self, tParser):
        clsItems = self.buildTapiInfo(tParser)
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        keyList = clsItems.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = clsItems[obj]
            print_str = value.printTable(table_dict, print_str, tapi_dict)
        print print_str

    def printTapiInfoToFile(self, tParser, f):
        print_str = self.printTapiTree(tParser)
        print >> f, print_str


if __name__ == '__main__':
    parser = MetaClassParser()
    curPath = os.path.dirname(__file__)

    if len(sys.argv) > 1:
        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")
        p2 = MetaClassParser()
        p2.read_xml("stcFramework.processed.xml")
        
        pb = MetaClassParser()
        pb.read_xml("stcRoutingCore.processed.xml")
        
        p3 = MetaClassParser()
        p3.read_xml("stcPcep.processed.xml")
        
        p4 = MetaClassParser()
        p4.read_xml("stcIsis.processed.xml")
       
        p5 = MetaClassParser()
        p5.read_xml("stcOspfv2.processed.xml")
               
        p6 = MetaClassParser()
        p6.read_xml("stcRsvp.processed.xml")
        
        p7 = MetaClassParser()
        p7.read_xml("stcLdp.processed.xml")

        pa = MetaClassParser()
        pa.read_xml("stcRoutingWizard.processed.xml")
                
        p = MetaClassParser()
        p.read_xml("stcVpn.processed.xml")
        mapping = MetaClassManager.getClassMapping(p.pluginName)
        MetaClassManager.printDict(mapping)
        p.printTree()
        p.printXml()

    else:
        if platform.system().startswith('Windows'):
            path = '..\\..\\..\\..\\UnitTest\\'
        else:
            path = './/'

        m = MetaClassManager.splitName('LspPerMessage')
        n = MetaClassManager.splitName('LSPPerMessage')
        print m, n
        k = MetaClassManager.splitName('LSPPerMESSAGE')
        j = MetaClassManager.splitName('LspPERMessage')
        print k, j

        assert m == 'lsp_per_message'
        assert m == n
        assert m == k
        assert m == j

        import array

        # arr = ["6.xml"]
        arr = ["2.xml", "3.xml", "6.xml", "450-t.xml", "isisUt.xml"]
        p = MetaClassParser()
        myfile = file("testit.txt", 'w')
        for k, v in enumerate(arr):
            fileName = os.path.join(curPath, path + v)
            p.read_xml(fileName)
            mapping = MetaClassManager.getClassMapping(p.pluginName)
            MetaClassManager.printDictToFile(myfile, mapping)
        myfile.close()

        file_object = open('testit.txt')
        all_the_text = file_object.read()
        file_object.close()

        fileName = os.path.join(curPath, path + 'testit_expected.txt')

        file_object_cmp = open(fileName)
        all_the_text_cmp = file_object_cmp.read()
        file_object_cmp.close()

        assert all_the_text_cmp == all_the_text
    print "end"
