#!/usr/bin/env python
#this tool is used internal for the STC which include the STAK command developered by XTAPI team will not require such action
#give the folder of the source code, copy the internal folder related to stak to the STAKCommands folder
#the virtual env name is spirent.xtapi
#use stakvirtualenv.pyc to install the virtual env and install the xtapi package to the virtual env
#the input:
#-d code package, include the stak folder and the .tar file
#-v the stc version
import os
import sys
import platform
import shutil
import stat
import re

def chmodtree(file, mode):
	os.chmod(file, mode)
	if os.path.isdir(file):
		for subFile in os.listdir(file):
			subFileNew = os.path.join(file,subFile)
			chmodtree(subFileNew, mode)
def main():
	argv = list(sys.argv)
	prg = argv.pop(0)
	usageMsg = '\nusage: python %s [options] virtualenv_name\n'\
					'show help: python %s --help' % (prg, prg)

	srcCodeDir = None
	venvName = 'spirent.xtapi'
	stcStakDir = ''
	stcStakVirtualDir = ''
	stcInstallDir = ''
	
	#################################################################################################################
	#get the dir of the src code and the target stc stak dir and stc install dir
	#################################################################################################################
	
	while argv and argv[0].startswith('-'):
		arg = argv.pop(0)
		if arg == '-d':
			if not argv:
				print >> sys.stderr, 'missing package dir after -d'
				return 1
			srcCodeDir = argv.pop(0)
		elif arg == '-v':
			if not argv:
				print >> sys.stderr, 'missing package dir after -v'
				return 1
			stcVersion = argv.pop(0)
			
	OriDir = os.getcwd()
	if not srcCodeDir:
		srcCodeDir = OriDir
	# stc install dir env: STC_INSTALL_DIR,
	stcInstallDir = os.environ['STC_INSTALL_DIR']
	if platform.system().startswith('Windows'):
		# if the ProgramData is always here?????
		stcStakDir='C:\ProgramData\Spirent\TestCenter '+stcVersion+'\STAKCommands'
		stcStakVirtualDir = 'C:\ProgramData\Spirent\TestCenter '+stcVersion+'\STAKvirtualenvs'
		stakSrcCodeDir = os.path.join(srcCodeDir, 'stak\\spirent\\xtapi')
		xmlFileSrc = os.path.join(srcCodeDir, 'stak\\stc_xtapiCommands.xml')
		stakEnvSrcCodeDir = os.path.join(srcCodeDir,'stak_env')
		xtapiStakDir = os.path.join(stcStakDir, 'spirent\\xtapi')
	else:
		stcStakDir = os.path.join(stcInstallDir, 'STAKCommands')
		stcStakVirtualDir = os.path.join(stcInstallDir, 'STAKvirtualenvs') 
		stakSrcCodeDir = os.path.join(srcCodeDir, 'stak/spirent/xtapi')
		xmlFileSrc = os.path.join(srcCodeDir, 'stak/stc_xtapiCommands.xml')
		stakEnvSrcCodeDir = os.path.join(srcCodeDir,'stak_env')
		xtapiStakDir = os.path.join(stcStakDir, 'spirent/xtapi')
	
	#################################################################################################################
	#copy the stak command code to the specipied dir to finish the stak installation
	#################################################################################################################
	if os.path.isfile(os.path.join(stcStakDir, 'stc_xtapiCommands.xml')):
		os.chmod(os.path.join(stcStakDir, 'stc_xtapiCommands.xml'), stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
		os.remove(os.path.join(stcStakDir, 'stc_xtapiCommands.xml'))
	shutil.copy(xmlFileSrc, stcStakDir)
	#if the xtapiStakDir exists, need to remove it and re-install
	if os.path.isdir(xtapiStakDir):
		chmodtree(xtapiStakDir, stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
		shutil.rmtree(xtapiStakDir)
	shutil.copytree(stakSrcCodeDir, xtapiStakDir)
	
	
	#################################################################################################################
	#install the STAK virtual env
	#1. use the src code in the "stak_env" to creat the egg pkg
	#2. use the stakvirtualenv.pyc to install the virtual env and at the same time the pkg will be installed in the virtual env created
	#################################################################################################################
	
	stepmsg = "===step1. use the src code in the stak_env to creat the egg pkg"
	print stepmsg
	stakEnvPkgs = []
	chmodtree(stakEnvSrcCodeDir, stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
	stakEnvTemp = os.path.join(srcCodeDir,'stakEnvTemp')
	if os.path.isdir(stakEnvTemp):
		chmodtree(stakEnvTemp, stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
		shutil.rmtree(stakEnvTemp)
	shutil.copytree(stakEnvSrcCodeDir, stakEnvTemp)
	os.chdir(stakEnvTemp)
	cmd = 'python setup.py sdist --formats=gztar'
	os.system(cmd)
	for file in os.listdir('dist'):
		if re.match('.*\.tar\.gz',file):
			if platform.system().startswith('Windows'):
				stakEnvPkgs.append(os.path.join(os.path.join(srcCodeDir,'stakEnvTemp\dist'), file))
			else:
				stakEnvPkgs.append(os.path.join(os.path.join(srcCodeDir,'stakEnvTemp/dist'), file))
	os.chdir(OriDir)		
	
	nextmsg = "===step2. use the stakvirtualenv.pyc to install the virtual env and at the same time the pkg will be installed in the virtual env created"
	print nextmsg
	os.chdir(stcStakVirtualDir)
	xtapiPkg = os.path.join(stcStakVirtualDir, 'xtapiPkg')
	if os.path.isdir(xtapiPkg):
		chmodtree(xtapiPkg, stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
		shutil.rmtree(xtapiPkg)
	os.mkdir(xtapiPkg)
	for stakEnvPkg in stakEnvPkgs:
		shutil.copy(stakEnvPkg, xtapiPkg)
	cmd = 'python stakvirtualenv.pyc -n -r -d xtapiPkg -s \"'+ stcInstallDir + '\" spirent.xtapi'
	os.system(cmd)
	shutil.rmtree(xtapiPkg)
	os.chdir(OriDir)
	#remove the temp folders
	shutil.rmtree(stakEnvTemp)
	
	if (float(stcVersion) >=4.60):
		if platform.system().startswith('Windows'):
			userprofile = os.environ['userprofile']
			userFolder = userprofile + '\Documents\Spirent\TestCenter ' + stcVersion + '\\STAKvirtualenvs\\'
			if os.path.isdir(userFolder + venvName):
				shutil.rmtree(userFolder + venvName)
			shutil.move(stcStakVirtualDir+'\\' + venvName, userFolder)
		else:
			userhome = os.environ['HOME']
			userFolder = userhome + '/Spirent/TestCenter ' + stcVersion + '/STAKvirtualenvs/'
			if os.path.isdir(userFolder + venvName):
				shutil.rmtree(userFolder + venvName)
			shutil.move(stcStakVirtualDir+'/' + venvName, userFolder)
		msg = stcVersion + ", So move " + stcStakVirtualDir +'\\' + venvName + " to " + userFolder
		print msg

if __name__ == '__main__':
    sys.exit(main())