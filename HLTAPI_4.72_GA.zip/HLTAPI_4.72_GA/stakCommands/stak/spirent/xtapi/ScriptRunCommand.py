import sys
import re
import os
import json
from StcPython import StcPython
import traceback

stc = StcPython()
from xtapi.metaclassManager import MetaClassParser, MetaClassManager
from xtapi.tapiclassManager import TapiInfoParser
          
class MetaClassRun(object):

    def __init__(self, metacls, index=""):
        self.name = metacls.getName() + str(index)
        self.metaCls = metacls
        self.myClsUserArgs = {}
        self.propDict = {}
        self.propDict[0] = {}
        self.childDict = {}
        self.parent = ""
        self.handleList = []

    def printDebug(self):
        return
        if isinstance(self.parent, str):
            print self.name + "\tparent: " + self.parent
        else:
            print self.name + "\tparent: " + self.parent.name
        print "\t" + str(self.myClsUserArgs)

    def IsInHandleList(self, handle):
        for hnd in self.handleList:
            if handle == hnd:
                return True
        return False

    def getName(self):
        return self.name

    def getClsName(self):
        return re.sub(r'.*\.', '', self.metaCls.getName())

    def getChildDict(self):
        return self.childDict

    def getPropDict(self):
        return self.propDict

    def setUserArgs(self, alias, value):
        self.myClsUserArgs[alias] = value

    def isChildOf(self, parentHnd):
        parentHnd = re.sub(r'\d+$', '', parentHnd)
        if type(self.parent) is str:
            if re.match(parentHnd, self.parent, flags=re.I) is not None:
                return True
        else:
            if re.match(parentHnd, self.parent.name, flags=re.I) is not None:
                return True
        return False

    def isFakeClsRun(self):
        metapropDict = self.metaCls.getPropertyDict()
        for index in self.propDict:
            for key in self.propDict[index]:
                if self.propDict[index][key] != "fake":
                    return False
                else:
                    defaultValue = metapropDict[key.lower()].defaultValue
                    self.propDict[index][key] = defaultValue
        return True

    def cloneParent(self, index, pparent):
        if not any(self.childDict):
            if isinstance(pparent, MetaClassRun):
                if len(pparent.childDict) < index:
                    if self.metaCls.isExistChildOf(self.parent.name):
                        t = re.search('[0-9]*$', self.name)
                        num = t.group(0)
                        myparent = self.parent.clone(num)
                        myparent.parent = pparent
                        while myparent.name in pparent.childDict:
                            myparent.name = myparent.name + "1"
                        pparent.childDict[myparent.name] = myparent
                        del self.parent.childDict[self.name]
                        self.parent = myparent
                        myparent.childDict[self.name] = self

    def clone(self, index):
        other = MetaClassRun(self.metaCls, index)
        return other

    def addChild(self, other):
        other.parent = self
        self.childDict[other.getName()] = other

    def removeChild(self, child):
        if child.getName() in self.childDict:
            del self.childDict[child.getName()]
            child.parent = ""

    def formatParams(self):
        aliasDict = self.metaCls.getAliasDict()
        myprops = {}
        max = 1
        bFlag = True
        childrelation = self.metaCls.getRelationCls("child")
        for key, value in self.myClsUserArgs.items():
            myprop = []
            if type(value) is list:
                if len(value) > max:
                    max = len(value)
                for val in value:
                    if type(val) is list:
                        myprop.append(val)
                        bFlag = False
                    else:
                        myprop.append(str(val))
            else:
                myprop.append(str(value))
            if len(childrelation) == 0:
                max = 1
                myprop = []
                myprop.append(value)        
            if self.metaCls.isCollectionParam(key) and bFlag:
                max = 1
                myprop = []
                myprop.append(value)
            myprops[str(aliasDict[key].getName())] = myprop
        for i in range(0, max):
            props = {}
            mtCls = self.metaCls
            for key in myprops:
                if type(myprops[key][i]) is str:
                    mykey = mtCls.paramDict[key.lower()]
                    if myprops[key][i].lower() == mykey.input.lower():
                        props[key] = mykey.output
                    else:
                        props[key] = myprops[key][i]
                else:
                    props[key] = myprops[key][i]
            if bFlag:
                self.propDict[i] = props
            else:
                propList = []
                for p in props:
                    if type(props[p]) is list:
                        k = 0
                        for val in props[p]:
                            if k >= len(propList):
                                d = {p: val}
                                propList.append(d)
                            else:
                                d = propList[k]
                                d[p] = val
                            k += 1
                if len(propList) == 0:
                    propList.append(props)
                self.propDict[i] = propList
        if len(self.propDict) == 0:
            self.propDict[0] = {}

    def processByPreOrder(self, handles, retDict):
        clsName = self.metaCls.getName()
        pattern = "("+clsName+"\d)"
        ret = re.search(pattern, handles, flags=re.I)
        if ret is not None:
            myhandle = ret.group()
            self.handleList.append(myhandle)
            retFlag = True
            classCondition = self.metaCls.getClassCondition()
            if any(classCondition):
                for condition in classCondition:
                    property = classCondition[condition].getProperty()
                    clsProp = property.split('.')
                    cls = clsProp[0]
                    property = clsProp[1]
                    hnd_key = retDict[cls]
                    if hnd_key in retValue:
                        object = retValue[hnd_key]
                        value = stc.get(object, property)
                        retFlag = classCondition[condition].IsPass(value)
                        if not retFlag:
                            break
            if not retFlag:
                return
            retDict[clsName.lower()] = myhandle
            childrenHnd = stc.get(myhandle, 'children')
            for name in sorted(self.childDict.keys()):
                childValue = self.childDict[name]
                self.childDict[name].processByPreOrder(childrenHnd, retDict)
            
    def emulateByPreOrder(self, metaClsPropDict, phandle):
        if len(metaClsPropDict) > 0:
            self.doEmulate(phandle)
            for name in sorted(self.childDict.keys()):
                childValue = self.childDict[name]
                self.childDict[name].emulateByPreOrder(childValue.propDict,
                                                       self.handleList[-1])

    def doEmulate(self, phandle):
        if self.isChildOf(phandle):
            if self.metaCls.isExistChildOf(phandle):
                self.configUnder(phandle)
            elif len(self.handleList) > 0:
                self.config(self.handleList[-1])
            else:
                self.createUnder(phandle)
        else:
            print str("Can't be here for creating " + self.name + " under " +
                      phandle)
    
    def config(self, objhnd):
        if objhnd != "" and len(self.propDict) > 0:
            configDict = self.propDict[0]
            stc.config(objhnd, **configDict)

    def configUnder(self, parent):
        if parent != "" and len(self.propDict) > 0:
            propName = "children-" + str(self.getClsName())
            objhnd = stc.get(parent, propName)
            if objhnd != '':
                configDict = self.propDict[0]
                stc.config(objhnd, **configDict)
                self.handleList.append(objhnd)

    def createUnder(self, parent):
        if parent != "" and len(self.propDict) > 0:
            clsName = str(self.getClsName())
            configDict = self.propDict[0]
            configDict['under'] = parent
            objhnd = stc.create(clsName, **configDict)
            self.handleList.append(objhnd)

    def printScript(self):
        print self.propDict


class SnippetRun(object):
    def __init__(self, clsCategory):
        self.clsCategory = clsCategory
        self.curHandle = ""
        self.dmClsTree = {}
    
    def IsSnippet(self):
        if self.clsCategory == 'pcep':
            return False
        if self.curHandle == "":
            return False
        return True
    
    @staticmethod
    def getInstance(clsCategory, apiCategory, **arg):
        mymode = 'create'
        if 'mode' in arg:
            mymode = arg['mode'].lower()
        return ScriptRun.getInstance(clsCategory, apiCategory, mymode)
    
    def stcgetDmHandleList(self, metaCls):
        pcls = ""
        if 'parent' in metaCls.relationDict:
            plist = metaCls.relationDict['parent']
            for p in plist:
                if p == "project":
                    pcls = stc.get('project1', "children-" + metaCls.name)
                else:
                    pcls = self.stcgetDmHandleList(plist[p].classRefEx)
                    if pcls == "":
                        childstr = "children-" + p
                        pcls = stc.get('project1', childstr)
                        pcls = stc.get(pcls, "children-" + metaCls.name)
                    else:
                        for cls in pcls.split(" "):
                            stc.get(cls, "children-" + metaCls.name)
        return pcls           

    def processDmHandleList(self):
        if self.IsSnippet() is True:
            retDict = {}  
            for clsname in sorted(self.dmClsTree.keys()):
                clsTree = self.dmClsTree[clsname]
                childrenHnd = self.stcgetDmHandleList(clsTree.metaCls)
                clsTree.processByPreOrder(childrenHnd, retDict)
    
    def canAddToReturnList(self, hndName):
        if self.IsSnippet() is True:
            ret = re.search(hndName , self.curHandle, flags=re.I)
            if ret is not None:
                return False
        return True

class ScriptRun(SnippetRun):

    def __init__(self, clsCategory, apiCategory, mode='create'):
        #self.clsCategory = clsCategory
        self.apiCategory = apiCategory
        self.keySwitchObjList = []
        #self.dmClsTree = {}
        #self.curHandle = ""
        self.splitPropDict = []
        self.mode = mode
        self.argDict = {}
        super(ScriptRun, self).__init__(clsCategory)

    @staticmethod
    def getInstance(cls_category, api_category, mode='create'):
        if mode == 'create':
            return ScriptRun(cls_category, api_category)
        elif mode == 'modify':
            return ScriptRunModify(cls_category, api_category)
        return ScriptRunDelete(cls_category, api_category)

    def getKeySwitchValue_recur(self, handle, elval):
        getClsFunc = MetaClassManager.getMappedClass
        if handle == "project1":
            metaCls = getClsFunc(self.clsCategory, elval.getObj().lower())
            return metaCls.propertyDict[elval.getProp().lower()].defaultValue
        phnd = stc.get(handle, 'parent')
        if re.match(elval.getObj(), phnd, flags=re.I) is not None:
            return stc.get(phnd, elval.getProp())
        else:
            return self.getKeySwitchValue_recur(phnd, elval)

    def isNotInkeySwitchObjListOrUnderProject(self, element):
        parents = element.getParentClassName()
        for elname in element.getName().split("."):
            elname = elname.lower()
            matchFlag = re.match('framework.Project', parents, flags=re.I)
            if (elname in self.keySwitchObjList or matchFlag is not None or
                    len(self.keySwitchObjList) == 0):
                return False
        return True

    def addToDmClsTree(self, clsRun, phandle):
        pname = re.sub('[0-9]*$', '', phandle)
        parents = clsRun.metaCls.getParentClassName()
        if clsRun.parent == "":
            bFlag = clsRun.metaCls.isChildof(pname)
            eFlag = clsRun.metaCls.isChildof('EmulatedDevice')
            pFlag = clsRun.metaCls.isChildof('Project')
            portFlag = clsRun.metaCls.isChildof('Port')
            if pname != "" and bFlag is True:
                clsRun.parent = phandle
            elif eFlag is  True:
                if pname == 'host' or pname == 'emulateddevice':
                    clsRun.parent = phandle
                elif pname == 'router':
                    clsRun.parent = phandle
            elif portFlag is True:
                if pname == 'port':
                    clsRun.parent = phandle
            elif pFlag is True:
                clsRun.parent = 'project1'
        if clsRun.parent != "":
            self.dmClsTree[clsRun.getName()] = clsRun
       
    def checkDmClsTree(self, clsRun, phandle, mylink, myindex):
        name = clsRun.getName()
        if name not in self.dmClsTree:
            k = 0
            parent = ""
            plugin = clsRun.metaCls.pluginName
            for el in mylink:
                element = MetaClassManager.getMappedClass(plugin, el)
                pClsRun = MetaClassRun(element, myindex)
                if k == 0:
                    self.addToDmClsTree(pClsRun, phandle)
                else:
                    parent.addChild(pClsRun)
                parent = pClsRun
                k += 1
            if parent != "":
                parent.addChild(clsRun)
            else:
                msg = " are not consistent with other args, will be skipped."
                print str(clsRun.myClsUserArgs) + msg
                return ""
        return clsRun

    def formatUserArgs(self, **arg):
        prefix = TapiInfoParser.interfaceDict[self.apiCategory].auto_prefix
        myprops = {}
        max = 1
        bFlag = True
        for key, value in arg.items():
            myprop = []
            if type(value) is list:
                if len(value) > max:
                    max = len(value)
                for val in value:
                    if type(val) is list:
                        myprop.append(val)
                        bFlag = True
                    else:
                        myprop.append(str(val))
            else:
                myprop.append(str(value))
            mykey = prefix + key
            myprops[mykey] = myprop
        for i in range(0, max):
            props = {}
            for key in myprops:
                if i < len(myprops[key]):
                    props[key] = myprops[key][i]
            if bFlag:
                self.splitPropDict.append(props)
            else:
                propList = []
                for p in props:
                    if type(props[p]) is list:
                        k = 0
                        for val in props[p]:
                            if k >= len(propList):
                                d = {p: val}
                                propList.append(d)
                            else:
                                d = propList[k]
                                d[p] = val
                            k += 1
                if len(propList) == 0:
                    propList.append(props)
                self.splitPropDict.append(propList)
        if len(self.splitPropDict) == 0:
            self.splitPropDict.append({})

    def run(self, myclass, **arg):
        if 'handle' in arg:
            self.curHandle = arg['handle']
        self.preProcess(myclass, **arg)
        self.formatUserArgs(**arg)
        for i, mydict in enumerate(self.splitPropDict):
            mytreelink = []
            self.argDict = mydict.copy()
            if i > 0:
                self.filterMetaClassEx(mytreelink, myclass, "", i+1,
                                       **self.argDict)
            else:
                self.filterMetaClass(mytreelink, myclass, "", i+1,
                                     **self.argDict)
        self.processDmClsTree(self.dmClsTree)
        self.processDmHandleList()
        return self.doRun()

    def processDmClsTree(self, dmClsTree):
        # ''check if the object in the dmClsTree has children, if there are
        # children, need to check if there this are are more than one object
        # for this class, if so, need to remove and keep only one. also the
        # childDict of the removed one need to be merged to the keeped object''
        baseClsDict = {}
        index = 1
        dmClsTreeTmp = dmClsTree.copy()
        for clsname in sorted(dmClsTreeTmp.keys()):
            clsTree = dmClsTree[clsname]
            childDict = clsTree.getChildDict()
            baseClsName = re.sub('[0-9]*$', '', clsname)
            if baseClsName not in baseClsDict:
                baseClsDict[baseClsName] = clsname
            else:
                index += 1
                if index > 1 and isinstance(clsTree.parent, MetaClassRun):
                    clsTree.cloneParent(index, clsTree.parent.parent)
                if any(childDict):
                    existFlag = False
                    index = 0
                    for child in childDict:
                        childClsTree = childDict[child]
                        childMetaCls = childClsTree.metaCls
                        if childMetaCls.isExistChildOf(clsname):
                            existFlag = True
                    if not existFlag:
                        clsnameReserved = baseClsDict[baseClsName]
                        clsTreeReserved = dmClsTree[clsnameReserved]
                        # merge the childDict the first one and
                        # then delete it from the dmClsTree
                        childDictReserved = clsTreeReserved.childDict
                        merge_dict = MetaClassManager.merge_dict_recursive
                        childDictNew = merge_dict(childDictReserved, childDict)
                        clsTreeReserved.childDict = childDictNew
                        del dmClsTree[clsname]
            self.processDmClsTree(childDict)

    def doRun(self):
        ret = {}
        for clsname in sorted(self.dmClsTree.keys()):
            clsTree = self.dmClsTree[clsname]
            ClsName = re.sub('[0-9]*$', '', clsname)
            if self.curHandle != "":
                if clsTree.IsInHandleList(self.curHandle) is False:
                    res = re.search(ClsName, self.curHandle, flags=re.I)
                    if res is not None:
                        clsTree.handleList.append(self.curHandle)
            clsTree.emulateByPreOrder(clsTree.propDict, clsTree.parent)
            flatternRet = self.flattenReturn(clsTree, ret)
            ret = MetaClassManager.merge_dict_recursive(ret, flatternRet)
        return ret

    def preProcess(self, myclass, **arg):
        myelement = ""
        for element in myclass:
            if len(element.keySwitchDict) > 0:
                myelement = element
                for key in list(arg.keys()):
                    if key in element.keySwitchDict:
                        if len(self.keySwitchObjList) > 0:
                            print "<error>duplicated key params??"
                        mySwitchDict = element.keySwitchDict[key].switchDict
                        strSwitchObjs = mySwitchDict[arg[key].lower()]
                        self.keySwitchObjList = re.split(r'[ \t\r\n]+',
                                                         strSwitchObjs,
                                                         flags=re.X)
        if (myelement != "" and self.curHandle != ""):
            protocolHnd = self.curHandle
            for el, elval in myelement.keySwitchDict.items():
                matchFlag = re.match(elval.getObj(), protocolHnd, flags=re.I)
                val = ''
                if matchFlag is not None:
                    val = stc.get(protocolHnd, elval.getProp())
                else:
                    childprop = 'children-' + elval.getObj().lower()
                    childhnd = stc.get(protocolHnd, childprop)
                    if childhnd != "":
                        val = stc.get(childhnd, elval.getProp())
                    elif (len(self.keySwitchObjList) == 0):
                        val = self.getKeySwitchValue_recur(protocolHnd, elval)
                if (val != ""):
                    strSwitchObjs = elval.switchDict[val.lower()]
                    self.keySwitchObjList = re.split(r'[ \t\r\n]+',
                                                 strSwitchObjs, flags=re.X)

    def enumDmTree(self, dmClsTree, name):
        for clsname in dmClsTree:
            if clsname == name:
                pCls = dmClsTree[clsname]
                return pCls
            pCls = self.enumDmTree(dmClsTree[clsname].childDict, name)
            if pCls == "":
                continue
            else:
                return pCls
        return ""

    def enumerateDmTree(self, dmClsTree, dmLink, index, level):
        GetClsFunc = MetaClassManager.getMappedClass
        if level >= 0 and level < len(dmLink):
            pCls = ""
            for k in range(index, 0, -1):
                for i in range(level, -1, -1):
                    myname = dmLink[i] + str(k)
                    pCls = self.enumDmTree(dmClsTree, myname)
                    if pCls != "":
                        break
                if pCls != "":
                    break
            if pCls != "":
                for j in range(i+1, level+1):
                    myMapping = GetClsFunc(self.clsCategory, dmLink[j].lower())
                    childRun = MetaClassRun(myMapping, index)
                    pCls.addChild(childRun)
                    pCls = childRun
            return pCls
        return ""

    def filterMetaClassEx(self, mylink, myclass, parent, index, **arg):
        category = self.clsCategory
        GetClsFunc = MetaClassManager.getMappedClass
        for element in myclass:
            if (not element.isCreatable() or
                    self.isNotInkeySwitchObjListOrUnderProject(element)):
                continue
            clsRun = ""
            for key in list(arg.keys()):
                if key in element.aliasDict:
                    if clsRun == "":
                        clsRun = MetaClassRun(element, index)
                    clsRun.setUserArgs(key, arg[key])
            if clsRun != "":
                clsRun.formatParams()
                if parent == "":
                    if MetaClassParser.isInEntryClassDict(self.clsCategory,
                                                          element.name):
                        self.addToDmClsTree(clsRun, self.curHandle)
                    else:
                        parent = self.enumerateDmTree(self.dmClsTree,
                                                      mylink,
                                                      index,
                                                      len(mylink)-1)
                        if parent == "" and len(mylink) > 3:
                            parent = self.dmClsTree[mylink[-3]+'1']
                            for pCls in mylink[-2:]:
                                pCls = pCls.lower()
                                if parent != "":
                                    myMapping = GetClsFunc(category,pCls)
                                    childRun = MetaClassRun(myMapping, index)
                                    parent.addChild(childRun)
                                    parent = childRun
                        if parent != "":
                            parent.addChild(clsRun)
                        else:
                            self.addToDmClsTree(clsRun, self.curHandle)
                else:
                    parent.addChild(clsRun)
            mylink.append(element.name)
            childrelation = element.getRelationCls("child")
            if len(childrelation) > 0:
                children = []
                for child in childrelation:
                    if childrelation[child].classRefEx.isCreatable():
                        children.append(childrelation[child].classRefEx)
                self.filterMetaClassEx(mylink, children, clsRun, index, **arg)
            mylink.remove(element.name)

    def filterMetaClass(self, mylink, myclass, parent, index, **arg):
        category = self.clsCategory
        GetClsFunc = MetaClassManager.getMappedClass
        for element in myclass:
            if (not element.isCreatable() or
                    self.isNotInkeySwitchObjListOrUnderProject(element)):
                continue
            clsRun = ""
            argList = []
            for key in list(self.argDict.keys()):
                if key in element.aliasDict:
                    if clsRun == "":
                        clsRun = MetaClassRun(element, index)
                    clsRun.setUserArgs(key, self.argDict[key])
                    argList.append(key)
            if clsRun != "":
                clsRun.formatParams()
                if parent == "":
                    if MetaClassParser.isInEntryClassDict(self.clsCategory,
                                                          element.name):
                        self.addToDmClsTree(clsRun, self.curHandle)
                        clsRun = self.checkDmClsTree(clsRun, self.curHandle,
                                            mylink, index)
                    else:
                        bflag = False
                        for pCls in mylink:
                            matchFlag = re.match(pCls, self.curHandle,
                                                 flags=re.I)
                            if matchFlag is not None:
                                bflag = True
                                continue
                            partmp = self.enumDmTree(self.dmClsTree,
                                                     pCls+str(index))
                            if partmp == "":
                                l_pCls = pCls.lower()
                                myMapping = GetClsFunc(category, l_pCls)
                                if parent != "":
                                    childRun = MetaClassRun(myMapping, index)
                                    parent.addChild(childRun)
                                    parent = childRun
                                    childRun.printDebug()
                                elif bflag:
                                    parent = MetaClassRun(myMapping, index)
                                    self.addToDmClsTree(parent,
                                                        self.curHandle)
                                    self.checkDmClsTree(parent,
                                                        self.curHandle,
                                                        mylink, index)
                                    parent.printDebug()
                            else:
                                parent = partmp
                        if parent != "":
                            parent.addChild(clsRun)
                        else:
                            self.addToDmClsTree(clsRun, self.curHandle)
                            clsRun = self.checkDmClsTree(clsRun, self.curHandle,
                                                mylink, index)
                else:
                    parent.addChild(clsRun)
                if clsRun != "":
                    clsRun.printDebug()
            #for option in argList:
            #    self.argDict.pop(option)
            mylink.append(element.name)
            childrelation = element.getRelationCls("child")
            if len(childrelation) > 0:
                children = []
                for child in childrelation:
                    if childrelation[child].classRefEx.isCreatable():
                        children.append(childrelation[child].classRefEx)
                self.filterMetaClass(mylink, children, clsRun, index,
                                     **self.argDict)
            mylink.remove(element.name)

    def flattenReturn(self, metaHndTree, retValue={}):
        retDict = TapiInfoParser.interfaceDict[self.apiCategory].getRetDict()
        metaCls = metaHndTree.metaCls
        if self.canAddToReturnList(metaCls.name) is False:
            return retValue
        classCondition = metaCls.getClassCondition()
        retFlag = True
        if any(classCondition):
            for condition in classCondition:
                property = classCondition[condition].getProperty()
                clsProp = property.split('.')
                cls = clsProp[0]
                property = clsProp[1]
                hnd_key = retDict[cls]
                if hnd_key in retValue:
                    object = retValue[hnd_key]
                    value = stc.get(object, property)
                    retFlag = classCondition[condition].IsPass(value)
                    if not retFlag:
                        break
        if not retFlag:
            return retValue
        myclsname = re.sub('[0-9]*$', '', metaHndTree.name).lower()
        strKey = ""
        if myclsname in retDict:
            strKey = str(retDict[myclsname])
        for hnd in metaHndTree.handleList:
            mycls = re.sub('[0-9]*$', '', hnd)
            if mycls in retDict:
                strKey = str(retDict[mycls])
            if strKey in retValue:
                retOri = retValue[strKey]
                if retOri != hnd:
                    retValue[strKey] = retOri + " " + hnd
            elif strKey != "":
                retValue[strKey] = hnd
        confChildrenCls = []
        for childIdx in metaHndTree.childDict:
            fRet = self.flattenReturn(metaHndTree.childDict[childIdx],
                                      retValue)
            retValue = MetaClassManager.merge_dict_recursive(retValue,
                                                             fRet)
            confChildCls = re.sub('[0-9]*$', '', childIdx).lower()
            if re.match('.', confChildCls):
                confChildCls = confChildCls.split('.')[-1]
            confChildrenCls.append(confChildCls)
        # check the default children which are not in the chilDict
        mapFunc = MetaClassManager.getMappedClass
        defaultChildrenClsDict = {}
        childrenHnd = stc.get(hnd, 'children').split()
        for childHnd in childrenHnd:
            childCls = re.sub('[0-9]*$', '', childHnd)
            childClsMapped = mapFunc(self.clsCategory, childCls)
            if childCls not in confChildrenCls:
                if not isinstance(childClsMapped, str):
                    clsRun = MetaClassRun(childClsMapped)
                    clsRun.handleList.append(childHnd)
                    defaultChildrenClsDict[childCls] = clsRun
        if any(defaultChildrenClsDict) > 0:
            for childIdx in defaultChildrenClsDict:
                defaultChildClsDict = defaultChildrenClsDict[childIdx]
                fRet = self.flattenReturn(defaultChildClsDict, retValue)
                retValue = MetaClassManager.merge_dict_recursive(retValue,
                                                                 fRet)
        return retValue


class ScriptRunModify(ScriptRun):
    def __init__(self, cls_type, api_type):
        super(ScriptRunModify, self).__init__(cls_type, api_type, 'modify')

    def doModify(self, **configArgDict):
        argsDict = configArgDict.copy()
        modifyHnd = argsDict['handle']
        del argsDict['handle']
        stc.config(modifyHnd, **argsDict)
        return ""

    def collectConfigArgs(self, argDict):
        clsName = re.sub('[0-9]*$', '', self.curHandle)
        clsMapped = MetaClassManager.getMappedClass(self.clsCategory, clsName)
        propDict = clsMapped.getAliasDict()
        
        configArgDict = {}
        configHnd = argDict['handle']
        className = re.sub('[0-9]*$', '', configHnd)
        configArgDict['handle'] = configHnd
        for element in argDict:
            if element in propDict:
                stcAttr = propDict[element].getName()
                value = argDict[element]
                v = value
                if type(value) is list:
                    for val in value:
                        if type(val) is list:
                            v = val
                configArgDict[stcAttr] = v
        return configArgDict

    def run(self, myclass, **arg):
        if 'handle' in arg:
            self.curHandle = arg['handle']
        # find the propDict of this calss
        # self.formatUserArgs(**arg)
        configArgDict = self.collectConfigArgs(arg)
        return self.doModify(**configArgDict)


class ScriptRunDelete(ScriptRun):
    def __init__(self, cls_type, api_type):
        super(ScriptRunDelete, self).__init__(cls_type, api_type, 'delete')

    def run(self, myclass, **arg):
        if 'handle' in arg:
            stc.delete(arg['handle'])
        return ""


def run_script(api_name, **arg):
    try:
        clsCategory = TapiInfoParser.getPluginNameFrom(api_name)
        if clsCategory is None:
            ##########################################################
            # need to move this part into one stak command.
            p1 = MetaClassParser()
            p1.read_xml("stcCore.processed.xml")
            p2 = MetaClassParser()
            p2.read_xml("stcFramework.processed.xml")
            #p3 = MetaClassParser()
            #p3.read_xml("stcMcastCore.processed.xml")
            
            pb = MetaClassParser()
            pb.read_xml("stcRoutingCore.processed.xml")

            p4 = MetaClassParser()
            p4.read_xml("stcIsis.processed.xml")
           
            p5 = MetaClassParser()
            p5.read_xml("stcOspfv2.processed.xml")
                   
            p6 = MetaClassParser()
            p6.read_xml("stcRsvp.processed.xml")
            
            p7 = MetaClassParser()
            p7.read_xml("stcLdp.processed.xml")
    
            pa = MetaClassParser()
            pa.read_xml("stcRoutingWizard.processed.xml")

            p = MetaClassParser()
            p.read_xml("stcPcep.processed.xml")
            t = TapiInfoParser()
            t.read_xml("stcPcep.tapi.xml")
            p.buildTapiInfo(t)
      
            pp = MetaClassParser()
            pp.read_xml("stcVpn.processed.xml")
            tt = TapiInfoParser()
            tt.read_xml("stcVpn.tapi.xml")
            pp.buildTapiInfo(tt)
            
            clsCategory = TapiInfoParser.getPluginNameFrom(api_name)
            ##############################################################
        ret = ""
        if clsCategory is not None:
            myrun = SnippetRun.getInstance(clsCategory, api_name, **arg)
            ret = myrun.run(MetaClassParser.entryClassDict[clsCategory], **arg)
        return ret
    except:
        print 'Unexpected exception caught in ScriptRunCommand:'
        stack_trace = traceback.format_exc()
        print stack_trace
        return stack_trace


def validate(ApiName, InputArgs):
    # print 'validating the objects'
    return ''


def run(ApiName, InputArgs):
    teststatus = True
    try:
        myargs = eval(InputArgs)
        ret = run_script(ApiName, **myargs)
        cmd_hnd = _get_this_cmd()
        if len(ret) > 0:
            result = json.dumps(str(ret))
            stc.config(cmd_hnd, RunResult=result)
        else:
            stc.config(cmd_hnd, RunResult=json.dumps(''))
    except:
        print 'Unexpected exception caught'
        stack_trace = traceback.format_exc()
        print stack_trace
        return False
    return teststatus


def reset():
    # print "ScriptRunCommand Reset method invoked"
    return True


def _get_this_cmd():
    try:
        thisCommand = __commandHandle__
    except NameError:
        return None
    return thisCommand
