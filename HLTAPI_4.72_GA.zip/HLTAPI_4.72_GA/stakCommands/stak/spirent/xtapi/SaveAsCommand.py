import re
import json
from StcPython import StcPython
import traceback

from xtapi.metaclassManager import MetaClassParser, MetaClassManager, CanSaveAs
from xtapi.tapiclassManager import TapiInfoParser

stc = StcPython()


def validate(Device, DeviceVar, ClassName, ReturnVar, Parse):
    # print 'validating the objects'
    return ''


def run(Device, DeviceVar, ClassName, ReturnVar, Parse):
    teststatus = True
    try:
        cmd_hnd = _get_this_cmd()
        scriptList = gen_script(Device, DeviceVar, ClassName,
                                ReturnVar, Parse)
        stc.config(cmd_hnd, Scripts=json.dumps(scriptList))
    except:
        print 'Unexpected exception caught'
        stack_trace = traceback.format_exc()
        print stack_trace
        return False
    return teststatus


def reset():
    print "SaveAsCommand Reset method invoked"
    return True


class DataModelTree:

    def build_data_model_tree(self, device, classname, objs):
        deviceDict = {}
        if objs == '':
            objs = stc.get(device, 'children-'+classname)
        objList = objs.split()
        objSortedList = objList[:]
        objSortedList.sort()
        index = -1
        for obj in objList:
            index += 1
            obj_indexed = objSortedList[index]
            deviceDict[obj_indexed] = stc.get(obj)
            # change all the keys to lower case
            attrs = deviceDict[obj_indexed].keys()
            for attr in attrs:
                value = deviceDict[obj_indexed][attr]
                del deviceDict[obj_indexed][attr]
                deviceDict[obj_indexed][attr.lower()] = value
            # add the class name for the obj
            if classname is not '':
                classnameNew = classname.lower()
            else:
                classnameNew = re.sub('[0-9]*$', '', obj)
            deviceDict[obj_indexed]['classname'] = classnameNew
            if 'children' in deviceDict[obj_indexed]:
                children = deviceDict[obj_indexed]['children']
                for child in children.split():
                    childDict = self.build_data_model_tree(obj, '', child)
                    deviceDict[obj_indexed][child] = childDict.values()[0]
        return deviceDict

    def get_real_configured_data(self, objDict, mappingDict):
        objDictUpdated = {}
        keyList = objDict.keys()
        for obj in keyList:
            objDictUpdated[obj] = {}
            if obj in objDict[obj]:
                objDictUpdated[obj] = objDict[obj][obj]
                continue
            # check the value of every attr
            parentObj = objDict[obj]['parent']
            parentClsName = re.sub('[0-9]*$', '', parentObj)
            classname = objDict[obj]['classname']
            mappingKey = parentClsName + '.' + classname
            if mappingKey in mappingDict:
                mappingKey = mappingKey
            elif classname in mappingDict:
                mappingKey = classname
            else:
                continue
            autoCreatedObj = mappingDict[mappingKey].isExistChildOf(obj)
            attrNeeded = ''
            valueNeeded = ''
            for attr in objDict[obj].keys():
                if not isinstance(objDict[obj][attr], dict):
                    paramDict = mappingDict[mappingKey].getParamDict()
                    propertyDict = mappingDict[mappingKey].getPropertyDict()
                    if attr in paramDict:
                        alias = str(paramDict[attr].getAlias())
                        value = objDict[obj][attr]
                        attrNeeded = alias
                        valueNeeded = value
                        defaultValue = ''
                        if attr in propertyDict:
                            dValueOri = propertyDict[attr].getDefaultValue()
                            defaultValue = str(dValueOri)
                        relation = 0
                        if (re.match('.*-targets', attr) or
                                re.match('.*-sources', attr) or
                                re.match('.*handle', attr)):
                            relation = 1
                        if value != defaultValue and value != '':
                            # here only when the attr is not default vlaue it
                            # will be added to the objDictUpdated, and if all
                            # of the attr is configured with default vlaue, if
                            # the obj is not autocreated one, then need to
                            # add one defualt attr to the objDictUpdated
                            if (attr in propertyDict and
							    propertyDict[attr].getMaxOccurs() != str(1) 
								and relation == 0):
                                value = '{{' + value + '}}'
                            if relation == 0:
                                objDictUpdated[obj][alias] = value
                            else:
                                objDictUpdated[obj][attr] = []
                                objDictUpdated[obj][attr].append(alias)
                                objDictUpdated[obj][attr].append(value)
                else:
                    # here need to process the children
                    objChildDict = {attr: objDict[obj][attr]}
                    objChildDictUpdated = self.get_real_configured_data(
                        objChildDict, mappingDict)
                    objDictUpdated[obj][attr] = objChildDictUpdated[attr]
            if not objDictUpdated[obj]:
                # if this is empty, then need to check if is obj is the
                # autogen obj
                if not autoCreatedObj and attrNeeded != '':
                    objDictUpdated[obj][attrNeeded] = valueNeeded
        return objDictUpdated


class ScriptGenerator:

    def __init__(self, cfgFunc, retDictTypeDict):
        self.relationObjsList = []
        self.relationDict = {}
        self.objRetDict = {}
        self.mappingDict = MetaClassManager.mapping
        self.cfgFunc = cfgFunc
        self.retDictTypeDict = retDictTypeDict
        self.dataModelTree = DataModelTree()

    def isInRelationObjsList(self, objkey):
        for relationObjDict in self.relationObjsList:
            if objkey in relationObjDict:
                return True
        return False

    def appendByCheck(self, objDict):
        for obj in objDict:
            if self.isInRelationObjsList(obj) is False:
                self.relationObjsList.append(objDict)

    def gen_protocol_script(self, objDictUpdated, objDict):
        scriptDictList = []
        keyList = objDictUpdated.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            scriptDict = {}
            script = ''
            scriptPre = ''
            childObjList = []
            classname = objDict[obj]['classname']

            attrList = objDictUpdated[obj].keys()
            if len(attrList) > 0:
                attrListSorted = sorted(attrList)
                for attr in attrListSorted:
                    if not isinstance(objDictUpdated[obj][attr], dict):
                        value = objDictUpdated[obj][attr]
                        if (re.match('.*-targets', attr) or
                                re.match('.*-sources', attr) or
                                re.match('.*handle', attr)):
                            attr = value[0]
                            relationClsName = re.sub('[0-9]*$', '',
                                                     value[1].split()[0])
                            relationObjParent = stc.get(value[1].split()[0],
                                                        'parent')
                            b_func = self.dataModelTree.build_data_model_tree
                            relationObjDict = b_func(relationObjParent,
                                                     relationClsName,
                                                     '')
                            valueNew = ''
                            i = 1
                            for v in sorted(value[1].split()):
                                handleVarDict = self.get_created_handle(
                                    {v: relationObjDict[v]}, 'modify', i)
                                if len(handleVarDict) == 0:
                                    continue
                                handleVar = handleVarDict.keys()[0]
                                i = i + 1
                                if handleVarDict[str(handleVar)] is 'next':
                                    p = stc.get(obj, 'parent')
                                    rDict = objDictUpdated
                                    rDict['parent'] = p
                                    rDict['classname'] = classname
                                    self.appendByCheck({obj: rDict})
                                    continue
                                scriptPre = scriptPre + \
                                    handleVarDict[str(handleVar)] + '\n'
                                valueNew = valueNew + '$'+str(handleVar) + ' '
                            if valueNew is not '':
                                valueNew = valueNew.rstrip()
                                value = '\"' + valueNew + '\"'
                                script = script + ' -'+attr + ' ' + value
                        else:
                            script = script + ' -'+attr + ' ' + value
                    else:
                        childObjList.append(attr)
                childOutFlag = True
                if obj in self.relationDict and self.relationDict[obj] == 1:
                    childOutFlag = False
                if obj in self.relationDict and self.relationDict[obj] == 0:
                    scriptDict['script'] = ''
                    scriptDict['pre'] = ''
                    self.relationDict[obj] = 1
                else:
                    scriptDict['script'] = script
                    scriptDict['pre'] = scriptPre
                scriptDict['classname'] = classname
                scriptDict['parent'] = objDict[obj]['parent']
                scriptDict['obj'] = obj
                scriptDict['child'] = []
                childObjList = sorted(childObjList)
                # for the relation config will not output it's children
                if childOutFlag:
                    for child in childObjList:
                        chObjDictUpdated = {child: objDictUpdated[obj][child]}
                        childObjDict = {child: objDict[obj][child]}
                        # if the this kind stc obj don't support to be output
                        # to the script here, then will skip.
                        childClsName = childObjDict[child]['classname']
                        flag = CanSaveAs.skip
                        if childClsName in self.mappingDict:
                            flag = self.mappingDict[childClsName].canSaveAs(
                                objDict[obj], childObjDict[child])
                        else:
                            parentchild = classname + "." + childClsName
                            if parentchild in self.mappingDict:
                                flag = self.mappingDict[parentchild].canSaveAs(
                                        objDict[obj], childObjDict[child])
                        if flag == CanSaveAs.save_next:
                            self.appendByCheck(childObjDict)
                            self.relationDict[child] = 0
                        elif flag == CanSaveAs.skip:
                            continue
                        cDict = self.gen_protocol_script(chObjDictUpdated,
                                                         childObjDict)
                        childScriptDict = cDict
                        scriptDict['child'].append(childScriptDict)
                scriptDictList.append(scriptDict)
        return scriptDictList

    def concat_script(self, scriptDictList):
        # scriptDict is a multiple children tree, use the left first method
        # to traversal the tree
        scriptDictFinal = {}
        for scriptDict in scriptDictList:
            script = {}
            childScriptDictList = []
            childScriptDictListLeft = []
            childScriptDictListRight = []
            classnameList = []
            if 'script' in scriptDict:
                script['main'] = scriptDict['script']
                script['pre'] = scriptDict['pre']
            if 'child' in scriptDict:
                childScriptDictList = scriptDict['child']
            obj = scriptDict['obj']
            parent = scriptDict['parent']
            if parent not in scriptDictFinal:
                scriptDictFinal[parent] = {}
            # find other the children will need to be use one more script
            # to create
            for childScriptDictL in childScriptDictList:
                for childScriptDict in childScriptDictL:
                    classnamechild = childScriptDict['classname']
                    if classnamechild not in classnameList:
                        classnameList.append(classnamechild)
                        childScriptDictListLeft.append(childScriptDict)
                    else:
                        childScriptDictListRight.append(childScriptDict)
            for childScriptDict in childScriptDictListLeft:
                childObj = childScriptDict['obj']
                childScriptDictFinal = self.concat_script([childScriptDict])
                for key in childScriptDictFinal:
                    if key == obj:
                        scriptDictFinal[obj] = {}
                        for subKey in childScriptDictFinal[obj]:
                            if subKey == childObj:
                                del scriptDictFinal[obj]
                                script['main'] = script['main'] + \
                                    childScriptDictFinal[obj][childObj]['main']
                                script['pre'] = script['pre'] +\
                                    childScriptDictFinal[obj][childObj]['pre']
                            else:
                                subS = childScriptDictFinal[parent][subKey]
                                scriptDictFinal[obj] = {subKey: subS}
                    else:
                        scriptDictFinal[key] = childScriptDictFinal[key]
            scriptDictFinal[parent][obj] = {}
            scriptDictFinal[parent][obj] = script
            for childScriptDict in childScriptDictListRight:
                childScriptDictFinal = self.concat_script([childScriptDict])
                for key in childScriptDictFinal:
                    if key not in scriptDictFinal:
                        scriptDictFinal[key] = {}
                    for subKey in childScriptDictFinal[key]:
                        scriptDictFinal[key][subKey] = {}
                        scriptDictFinal[key][subKey] = \
                            childScriptDictFinal[key][subKey]
        return scriptDictFinal

    def gen_complete_script(self, deviceDict, scriptDict, returnVar,
                            handleVar, mode):
        mapping = MetaClassManager.mapping
        scriptList = []
        i = 1
        returnVarOri = returnVar
        keyList = sorted(deviceDict.keys())
        for key in keyList:
            parent = deviceDict[key]['parent']
            obj = key
            children = ''
            if 'children' in deviceDict[key]:
                children = deviceDict[key]['children']
            childDictList = []
            handleVarDict = {}
            script = ''
            scriptPre = ''
            if parent in scriptDict:
                if obj in scriptDict[parent]:
                    clsRef = re.sub('[0-9]*$', '', obj)
                    if mapping[clsRef].isExistChildOfParents() is True:
                        mode = "modify"
                    # the script should be output
                    if handleVar == '':
                        handleVarDict = self.get_created_handle(deviceDict,
                                                                mode,
                                                                handleVar)
                        handleVar = handleVarDict.keys()[0]
                        scriptPre = handleVarDict[handleVar] + '\n'
                    script = str(script + 'set ' + str(returnVar) + ' [' +
                                 self.cfgFunc)
                    if handleVar != 'project':
                        # for the project level object, the mode and the
                        # handle should not output.
                        script = str(script + ' -handle' + ' ' + '$' +
                                     str(handleVar))
                        script = script + ' -mode ' + mode
                    script = script + scriptDict[parent][obj]['main']
                    if obj not in self.objRetDict:
                        self.objRetDict[obj] = str(returnVar)
                    script = script + ']'
                    scriptPre = scriptPre + scriptDict[parent][obj]['pre']
                    if scriptPre != '':
                        scriptList.append(str(scriptPre))
                    scriptList.append(str(script))
                    statusCheckStr = self.gen_status_info(returnVar,
                                                          self.cfgFunc)
                    scriptList.append(str(statusCheckStr))
            for child in children.split():
                childDict = {child: deviceDict[key][child]}
                childDictList.append(childDict)
            for childDict in childDictList:
                childScriptList = []
                mode = 'create'
                obj = childDict.keys()[0]
                returnVar = self.get_ret_var(obj)
                childScriptList = self.gen_complete_script(childDict,
                                                           scriptDict,
                                                           returnVar,
                                                           '',
                                                           mode)
                scriptList.extend(childScriptList)
            returnVar = returnVarOri+'_'+'a'+str(i)
            i = i + 1
        return scriptList

    def get_created_handle(self, objDict, mode, handleVar):
        handleVarDict = {}
        obj = objDict.keys()[0]
        parent = objDict[obj]['parent']
        classnameParent = re.sub('[0-9]*$', '', parent)
        classname = re.sub('[0-9]*$', '', obj)
        classnameIndx = re.sub('[a-z]*', '', obj)
        ret = self.get_ret_last_var(obj)
        if mode == 'modify':
            handleType = self.retDictTypeDict[classname]
        else:
            handleType = self.retDictTypeDict[classnameParent]
        handleVar = handleType+str(classnameIndx)
        if ret is 'next':
            handleVarDict[handleVar] = 'next'
            return handleVarDict
        handleVarDict[handleVar] = str('set ' + handleVar + ' [' + 'keylget ' +
                                       ret + ' ' + handleType + ']')
        return handleVarDict

    def get_ret_last_var(self, obj):
        parent = stc.get(obj, 'parent')
        if re.match('host|emulateddevice|router', obj):
            return 'next'
        if obj in self.objRetDict:
            ret = self.objRetDict[obj]
        elif re.match('project', parent):
            ret = MetaClassParser.retDict[obj]
        else:
            ret = self.get_ret_last_var(parent)
        return ret

    def get_ret_var(self, obj):
        classname = re.sub('[0-9]*$', '', obj)
        ret = classname + 'Ret'
        index = re.sub('[a-z]*', '', obj)
        ret = ret + str(index)
        return ret

    def gen_status_info(self, retVar, cmdName):
        statusCheckStr = ''
        statusCheckStr = str(statusCheckStr + 'set status [keylget ' + retVar +
                             ' status]\n')
        statusCheckStr = statusCheckStr + 'if {$status == 0} {\n'
        statusCheckStr = str(statusCheckStr + 'puts \"run ' + cmdName +
                             ' failed\"\n')
        statusCheckStr = statusCheckStr + 'puts $' + retVar + '\n'
        statusCheckStr = statusCheckStr + '} else {\n'
        statusCheckStr = str(statusCheckStr + 'puts \"***** run ' + cmdName +
                             ' successfully\"\n')
        statusCheckStr = statusCheckStr + '}\n'
        return statusCheckStr


def gen_script(deviceHandle, deviceVar, className, returnVar, Parse):
    ##########################################################
    # need to move this part into one stak command.
    if str(className).lower() not in MetaClassManager.mapping or Parse:
        if str(className).lower() in MetaClassManager.mapping:
            MetaClassManager.mapping = {}
        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")
        p2 = MetaClassParser()
        p2.read_xml("stcFramework.processed.xml")
        #p3 = MetaClassParser()
        #p3.read_xml("stcMcastCore.processed.xml")
        p4 = MetaClassParser()
        p4.read_xml("stcIsis.processed.xml")
       
        p5 = MetaClassParser()
        p5.read_xml("stcOspfv2.processed.xml")
               
        p6 = MetaClassParser()
        p6.read_xml("stcRsvp.processed.xml")
        
        p7 = MetaClassParser()
        p7.read_xml("stcLdp.processed.xml")

        pa = MetaClassParser()
        pa.read_xml("stcRoutingWizard.processed.xml")

        p = MetaClassParser()
        p.read_xml("stcPcep.processed.xml")
        t = TapiInfoParser()
        t.read_xml("stcPcep.tapi.xml")
        p.buildTapiInfo(t)

        pp = MetaClassParser()
        pp.read_xml("stcVpn.processed.xml")
        tt = TapiInfoParser()
        tt.read_xml("stcVpn.tapi.xml")
        pp.buildTapiInfo(tt)
    ##############################################################
    
    sDictConcat = {}
    scriptDict = {}
    dataModelTree = DataModelTree()
    interface = TapiInfoParser.getInterfaceFrom(className)
    MetaClassManager.mapping = MetaClassManager.pluginClsMap[interface.plugin]
    cfgFunc = interface.APIName
    retDictTypeDict = interface.getRetDict()
    generator = ScriptGenerator(cfgFunc, retDictTypeDict)
    returnVarBk = returnVar
    scriptList = []
    generator.objRetDict = {deviceHandle: deviceVar}
    generator.relationObjsList = []
    i = 0
    clsNameToGenDict = {}
    clsNameToGenDict['device'] = {}
    clsNameToGenDict['project'] = {}
    for firstCls in MetaClassParser.entryClassDict[interface.plugin]:
        if firstCls.canCreate == 'false':
            continue
        firstClsName = str(firstCls.name).lower()
        parentList = firstCls.relationDict['parent']
        for parentType, parentInst in parentList.items():
            if re.match('.*emulateddevice.*', parentType):
                parentObj = deviceHandle
                clsNameToGenDict['device'][firstClsName] = parentObj
            elif re.match(".*project.*", parentType):
                parentObj = 'project1'
                clsNameToGenDict['project'][firstClsName] = parentObj
                firstCls.canCreate = 'false'
            else:
                continue
    for clsNameLevel in "project device".split():
        if clsNameLevel == 'project':
            parentObj = 'project1'
        else:
            parentObj = deviceHandle
        clsNameDict = clsNameToGenDict[clsNameLevel]
        clsNameList = clsNameDict.keys()
        for clsName in clsNameList:
            parentObj = clsNameDict[clsName]
            deviceDict = dataModelTree.build_data_model_tree(parentObj,
                                                             clsName,
                                                             '')
            if deviceDict == {}:
                continue
            scriptDictList = []
            try:
                deviceDictUpdated = dataModelTree.get_real_configured_data(
                    deviceDict,
                    MetaClassManager.mapping)
                scriptDictList = generator.gen_protocol_script(
                    deviceDictUpdated,
                    deviceDict)
            except Exception, e:
                scriptList.append(str(e))
                scriptList.append('Unexpected exception caught')
                stack_trace = traceback.format_exc()
                scriptList.append(stack_trace)
            if len(scriptDictList) > 0:
                scriptDict = scriptDictList[0]
                sDictConcat = generator.concat_script(scriptDictList)
                print sDictConcat
                if parentObj == 'project1':
                    handleVar = 'project'
                    obj = deviceDict.keys()[0]
                    preStr = 'set project \"project1\"'
                    sDictConcat['project1'][obj]['pre'] = preStr
                else:
                    handleVar = deviceVar
                mode = 'create'
                scriptListTemp = []
                scriptListTemp = generator.gen_complete_script(deviceDict,
                                                               sDictConcat,
                                                               returnVar,
                                                               handleVar,
                                                               mode)
                scriptList.extend(scriptListTemp)
                i = i + 1
                returnVar = returnVarBk + '_' + str(i)
    # relation config
    for relationObjDict in generator.relationObjsList:
        relationObjDictUpadated = dataModelTree.get_real_configured_data(
            relationObjDict,
            MetaClassManager.mapping)
        scriptDict = generator.gen_protocol_script(relationObjDictUpadated,
                                                   relationObjDict)
        sDictConcat = generator.concat_script(scriptDict)
        handleVar = ''
        stcObj = relationObjDictUpadated.keys()[0]
        if stcObj in generator.objRetDict:
            mode = 'modify'
        else:
            mode = 'create'
        i = i + 1
        returnVar = returnVarBk + '_' + str(i)
        scriptListTemp = []
        scriptListTemp = generator.gen_complete_script(relationObjDict,
                                                       sDictConcat,
                                                       returnVar,
                                                       handleVar,
                                                       mode)
        scriptList.extend(scriptListTemp)
    MetaClassParser.retDict = generator.objRetDict
    return scriptList


def _get_this_cmd():
    try:
        thisCommand = __commandHandle__
    except NameError:
        return None
    return thisCommand
