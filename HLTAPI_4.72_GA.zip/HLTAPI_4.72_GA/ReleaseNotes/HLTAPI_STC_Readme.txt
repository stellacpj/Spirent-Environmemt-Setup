======================================================================
Spirent HLTAPI  (hltapi_stc_4.72)                 Date: 06/30/17
======================================================================


Table of Contents
-----------------
        System Requirements (special):
        APIs Supported:
        Changes:
        Key Known Issues:
        General Restrictions:
        Installation Instructions (special):
        

System Requirements (special):
        This release supports Single Processor, Dual Processor, Windows, Enterprise Linux 3, RedHat 8.0
        This release supports Spirent TestCenter Release 4.67/4.72
        TCL 8.4.13 (reuqire Tclx and IP package)
        Cards: MSA2001A/B EDM-2003A, XFP-2001A/B, CPR2001A/B, CPR2002A/B, EDM2001A/B, FBR2001A/B, UPY2001A, UPY2002A, WAN2002A, XFP-4004A, SFP-4001A, CM, CV, DX/DX2, FX/FX2, MX/MX2, VM


APIs Supported:
        Session API
        Alarms
        Traffic API
        Test_config/Test_control
        40G/100G port suport
        Capture, Capture Filter
        BGPv4, BGPv6
        DHCPv4,DHCPv6,DHCP-PD
        STP
        IGMPv1, IGMPv2, IGMPv3, IGMPv1 Querier, IGMPv2 Querier, IGMPv3 Querier
        IS-IS IPv4, IS-IS IPv6
        IPv6 Autoconfiguration
        LDP IPv4
        MLDv1, MLDv2
        Multicast groups
        OSPFv2, OSPFv3
        OSPF Topology
        Ping
        PIM
        PPP, PPPoX/IPv4, pppox server, L2TP
        RIPv1, RIPv2, RIPng 
        RSVP IPv4
        Route flapping for BGP, IS-IS, OSPF, RIP
        BFD
        L2TP
        Graceful restart for BGP, IS-IS, LDP, OSPF, RSVP
        GRE for RSVP, BGP, LDP, OSPF, PIM, RIP
        ATM for BGP, ISIS, OSPF, PPPOx, Pppox Server, RIP, ANCP, L2TP, DHCP, DHCP server
        Ethernet OAM 
        Ethernet EFM
        MVPN
        ANCP
        RFC2544, RFC3918
        LACP
        SIP
        FCOE/FIP, FC
        LLDP
        PTP
        Lab Server mode support
        802.1x
        MPLS-TP
        CFM PDUs Capture Filters.
        Save to High Level API
        Configure multiple protocols on the same device, including RSVP/IGMP/LDP/RIP/OSPFV2/OSPFV3/ISIS/BGP/DHCPV6/DHCPV6PD/DHCPV4/PIM/SIP/MLD/IGMP QUERIER.
        VxLan
        HLTAPI for Perl
        HLTAPI for Python
        Save as iTest
        40G/100G L1 API
        PCEP
        NG-MPVN
        HTTP Client and HTTP server
        VXLAN overlay EVPN (wizard)
        TWAMP
        Control Plane Convergence
        IPTV support in HLTAPI
        HLTAPI support for video quality analyzer
        SyncE
        Multicast Routing Wizard
        Openflow, Openflow switch
        Save as Robot

Changes:
        (from release 4.67 to release 4.72):
        a) New features: 
            01188980  SyncE Support in HLTAPI
            01185797  Hltapi Support for Multicast Routing Wizard
                      Openflow switch
                      Save as Robot

        b) Enhancement:
           01188441  Specify recordsperpage in traffic_stats
           01189292  ER for 25/50G speed support in HLTAPI Python , Perl , TCL ( for MX3/FX3/DX3 quint speed modules)
           01189849  Error while creating ICMP header with icmp_type=30
           01174450  ER to add None(empty source-list) filter mode option in IGMPv3 in HLTAPI
           01197609  HLTAPI Python - handles returned from interface_config is not a standard python list format
           01188982  Enhance Get Handles in HLTAPI
           01200374  Control API to start ISIS emulation performs a device start that starts all the emulations on the device
           01200457  ER request for Many_to_Many endpoint mapping in streamblock creation
           01201319  Deactivate ipv6 autoconfiguration
           01200373  RSVP Tunnel Configuration: Not able to increment the source IP address of the Ingress tunnel.
           01208238  Enhancement request to add support for "Enable IPv6 Gateway Learning" in HLTAPI
           01209489  Enhancement to support 8K devices in each of 4 vlans in HLTAPI
           01209408  [vSTC automation]how to customize Bucket size unit
           01213162  Enhancement HLTAPI on PFC Measure and retrieving stats
           01215450  Enhancement for AutoNegotiation Restart under interface_config API in HLTAPI
           01217137  Enhancement to add Custom Header in stream block without Encapsulation in HLTAPI
           01217280  Need FEC enabled on 100Gig Links by default in HLTAPI
           01223859  packet_stats enhancement in HLTAPI
           01223864  HLTAPI traffic_config reset deletes all streamblocks
           01223855  HLTAPI Traffic Stats enhancement.
           01223868  Enhancement to support Frame threshold in HLTAPI.
           01223877  Enhancement for Capture mode - Byte Offset/Range & Userdefined stats.
           01224172  HLTAPI enhancement for supporting per streamblock burst
           01224805  ER to support block mode config for RSVP, LDP and Device config.(Doc in Spirent HLTAPI Temporary Reference)
                     Add custom options support in DHCPv4 group config (Doc in Spirent HLTAPI Temporary Reference)


         c) Issue resolutions:
           01187241  create BGP routes works in STC4.52 but failed in STC4.58 using HLTAPI
           01189106  Gateway on the DHCPv4 is set to default value{192.85.2.1}
           01190715  EOAM TLV is not getting added in right order
           01192102  Wait attribute not working with test_rfc3918_control API.
           01192295  Observing invalid handle "sequencerloopcommand1" error while running rfc3918 test
           01190735  DHCPV4 stats takes time to fetch the correct stats
           01192276  [HLTAPI][cisco] num_frames is always zero for LAG port. But able to get the frames
           01192431  Issue in vlan_ether_type of emulation_oam_config_msg
           01200054  Negative counters found
           01200281  HLTAPI Python module (sth.py)
           01209390  Issues with scaling in Hltapi more than 2000 devices (expanded)
           01210075  Issue in modfication of emulation_device_config
           01213711  emulation_ldp_route_config doesnt work in modify mode
           01214406  [HLTAPI] Local IPV6 address and AS no are not incrementing in BGP config
           01215467  LinkLocalAddress Config Issue in HLTAPI
           01217932  The 'dropped_pkts' is 0. but the dropped_pkts is more than 0 when using the old package.
           01219617  Twamp Stats-session_name is not being fetched in HLTAPI
           01219321  Encapsulation Error In HLTAPI script
           01220155  link_local_ipv6_addr Issue in HLTAPI
           01218656  Not able to modify filter_mode in emulation_igmp_group_config
           01222340  HLTAPI TrafficFunction not handling
      
Insta llation Instructions:
         please refer to HLTAPI Environment Installation Guide for detail


Prere quisites to support PCEP with HLTAPI 4.72GA:
    For PCEP user, please notice that you will need follow below steps to use PCEP API in HLTAPI 4.72GA:
         1. Please make sure Python 2.7 is installed and environment variable "STC_INSTALL_DIR" is set.
         2. Go to HLTAPI SourceCode location and enter into "stakCommands" folder
         3. execute command "python stak_register.py -v 4.72"
      
    We will move the dependence on these steps in future release.